﻿
namespace smart_department
{
    partial class Form_Slide_Record_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Slide_Record_admin));
            this.comboBox_intake_select_Slide_Record = new System.Windows.Forms.ComboBox();
            this.txt_insert_recordlink_Slide_Record = new System.Windows.Forms.TextBox();
            this.lbl_recordlink_Slide_Record = new System.Windows.Forms.Label();
            this.txt_insert_slidelink_Slide_Record = new System.Windows.Forms.TextBox();
            this.lbl_slidelink_Slide_Record = new System.Windows.Forms.Label();
            this.txt_insert_date_Slide_Record = new System.Windows.Forms.TextBox();
            this.lbl_date_Slide_Record = new System.Windows.Forms.Label();
            this.txt_insert_course_id_Slide_Record = new System.Windows.Forms.TextBox();
            this.lbl_intake_Slide_Record_select = new System.Windows.Forms.Label();
            this.txt_insert_Slide_Record_intake = new System.Windows.Forms.TextBox();
            this.lbl_intake_Slide_Record = new System.Windows.Forms.Label();
            this.txt_insert_section_Slide_Record = new System.Windows.Forms.TextBox();
            this.lbl_sec_Slide_Record = new System.Windows.Forms.Label();
            this.btn_insert_Slide_Record = new System.Windows.Forms.Button();
            this.lbl_course_id_Slide_Record = new System.Windows.Forms.Label();
            this.btn_back_fm5 = new System.Windows.Forms.Button();
            this.dateTimePicker_Slide_Record = new System.Windows.Forms.DateTimePicker();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.lbl_top_insert_SlideRecord = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBox_intake_select_Slide_Record
            // 
            this.comboBox_intake_select_Slide_Record.FormattingEnabled = true;
            this.comboBox_intake_select_Slide_Record.Location = new System.Drawing.Point(400, 177);
            this.comboBox_intake_select_Slide_Record.Name = "comboBox_intake_select_Slide_Record";
            this.comboBox_intake_select_Slide_Record.Size = new System.Drawing.Size(73, 24);
            this.comboBox_intake_select_Slide_Record.TabIndex = 73;
            this.comboBox_intake_select_Slide_Record.SelectedIndexChanged += new System.EventHandler(this.comboBox_intake_select_Slide_Record_SelectedIndexChanged);
            // 
            // txt_insert_recordlink_Slide_Record
            // 
            this.txt_insert_recordlink_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_recordlink_Slide_Record.Location = new System.Drawing.Point(537, 322);
            this.txt_insert_recordlink_Slide_Record.Name = "txt_insert_recordlink_Slide_Record";
            this.txt_insert_recordlink_Slide_Record.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_recordlink_Slide_Record.TabIndex = 70;
            // 
            // lbl_recordlink_Slide_Record
            // 
            this.lbl_recordlink_Slide_Record.AutoSize = true;
            this.lbl_recordlink_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_recordlink_Slide_Record.Location = new System.Drawing.Point(537, 294);
            this.lbl_recordlink_Slide_Record.Name = "lbl_recordlink_Slide_Record";
            this.lbl_recordlink_Slide_Record.Size = new System.Drawing.Size(126, 25);
            this.lbl_recordlink_Slide_Record.TabIndex = 69;
            this.lbl_recordlink_Slide_Record.Text = "Record Link";
            // 
            // txt_insert_slidelink_Slide_Record
            // 
            this.txt_insert_slidelink_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_slidelink_Slide_Record.Location = new System.Drawing.Point(537, 249);
            this.txt_insert_slidelink_Slide_Record.Name = "txt_insert_slidelink_Slide_Record";
            this.txt_insert_slidelink_Slide_Record.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_slidelink_Slide_Record.TabIndex = 68;
            // 
            // lbl_slidelink_Slide_Record
            // 
            this.lbl_slidelink_Slide_Record.AutoSize = true;
            this.lbl_slidelink_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_slidelink_Slide_Record.Location = new System.Drawing.Point(537, 221);
            this.lbl_slidelink_Slide_Record.Name = "lbl_slidelink_Slide_Record";
            this.lbl_slidelink_Slide_Record.Size = new System.Drawing.Size(107, 25);
            this.lbl_slidelink_Slide_Record.TabIndex = 67;
            this.lbl_slidelink_Slide_Record.Text = "Silde Link";
            // 
            // txt_insert_date_Slide_Record
            // 
            this.txt_insert_date_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_date_Slide_Record.Location = new System.Drawing.Point(537, 174);
            this.txt_insert_date_Slide_Record.Name = "txt_insert_date_Slide_Record";
            this.txt_insert_date_Slide_Record.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_date_Slide_Record.TabIndex = 66;
            // 
            // lbl_date_Slide_Record
            // 
            this.lbl_date_Slide_Record.AutoSize = true;
            this.lbl_date_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date_Slide_Record.Location = new System.Drawing.Point(537, 146);
            this.lbl_date_Slide_Record.Name = "lbl_date_Slide_Record";
            this.lbl_date_Slide_Record.Size = new System.Drawing.Size(138, 25);
            this.lbl_date_Slide_Record.TabIndex = 65;
            this.lbl_date_Slide_Record.Text = "Perform Date";
            // 
            // txt_insert_course_id_Slide_Record
            // 
            this.txt_insert_course_id_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_course_id_Slide_Record.Location = new System.Drawing.Point(73, 322);
            this.txt_insert_course_id_Slide_Record.Name = "txt_insert_course_id_Slide_Record";
            this.txt_insert_course_id_Slide_Record.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_course_id_Slide_Record.TabIndex = 64;
            // 
            // lbl_intake_Slide_Record_select
            // 
            this.lbl_intake_Slide_Record_select.AutoSize = true;
            this.lbl_intake_Slide_Record_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_Slide_Record_select.Location = new System.Drawing.Point(402, 143);
            this.lbl_intake_Slide_Record_select.Name = "lbl_intake_Slide_Record_select";
            this.lbl_intake_Slide_Record_select.Size = new System.Drawing.Size(73, 25);
            this.lbl_intake_Slide_Record_select.TabIndex = 62;
            this.lbl_intake_Slide_Record_select.Text = "Select";
            // 
            // txt_insert_Slide_Record_intake
            // 
            this.txt_insert_Slide_Record_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_Slide_Record_intake.Location = new System.Drawing.Point(73, 174);
            this.txt_insert_Slide_Record_intake.Name = "txt_insert_Slide_Record_intake";
            this.txt_insert_Slide_Record_intake.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_Slide_Record_intake.TabIndex = 61;
            this.txt_insert_Slide_Record_intake.TextChanged += new System.EventHandler(this.txt_insert_Slide_Record_intake_TextChanged);
            // 
            // lbl_intake_Slide_Record
            // 
            this.lbl_intake_Slide_Record.AutoSize = true;
            this.lbl_intake_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_Slide_Record.Location = new System.Drawing.Point(74, 146);
            this.lbl_intake_Slide_Record.Name = "lbl_intake_Slide_Record";
            this.lbl_intake_Slide_Record.Size = new System.Drawing.Size(71, 25);
            this.lbl_intake_Slide_Record.TabIndex = 60;
            this.lbl_intake_Slide_Record.Text = "Intake";
            // 
            // txt_insert_section_Slide_Record
            // 
            this.txt_insert_section_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_section_Slide_Record.Location = new System.Drawing.Point(73, 249);
            this.txt_insert_section_Slide_Record.Name = "txt_insert_section_Slide_Record";
            this.txt_insert_section_Slide_Record.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_section_Slide_Record.TabIndex = 59;
            // 
            // lbl_sec_Slide_Record
            // 
            this.lbl_sec_Slide_Record.AutoSize = true;
            this.lbl_sec_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sec_Slide_Record.Location = new System.Drawing.Point(73, 221);
            this.lbl_sec_Slide_Record.Name = "lbl_sec_Slide_Record";
            this.lbl_sec_Slide_Record.Size = new System.Drawing.Size(85, 25);
            this.lbl_sec_Slide_Record.TabIndex = 58;
            this.lbl_sec_Slide_Record.Text = "Section";
            // 
            // btn_insert_Slide_Record
            // 
            this.btn_insert_Slide_Record.Location = new System.Drawing.Point(914, 322);
            this.btn_insert_Slide_Record.Name = "btn_insert_Slide_Record";
            this.btn_insert_Slide_Record.Size = new System.Drawing.Size(59, 30);
            this.btn_insert_Slide_Record.TabIndex = 57;
            this.btn_insert_Slide_Record.Text = "GO";
            this.btn_insert_Slide_Record.UseVisualStyleBackColor = true;
            this.btn_insert_Slide_Record.Click += new System.EventHandler(this.btn_insert_Slide_Record_Click);
            // 
            // lbl_course_id_Slide_Record
            // 
            this.lbl_course_id_Slide_Record.AutoSize = true;
            this.lbl_course_id_Slide_Record.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course_id_Slide_Record.Location = new System.Drawing.Point(73, 294);
            this.lbl_course_id_Slide_Record.Name = "lbl_course_id_Slide_Record";
            this.lbl_course_id_Slide_Record.Size = new System.Drawing.Size(109, 25);
            this.lbl_course_id_Slide_Record.TabIndex = 56;
            this.lbl_course_id_Slide_Record.Text = "Course ID";
            // 
            // btn_back_fm5
            // 
            this.btn_back_fm5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm5.Location = new System.Drawing.Point(899, 448);
            this.btn_back_fm5.Name = "btn_back_fm5";
            this.btn_back_fm5.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm5.TabIndex = 55;
            this.btn_back_fm5.Text = "BACK";
            this.btn_back_fm5.UseVisualStyleBackColor = false;
            this.btn_back_fm5.Click += new System.EventHandler(this.btn_back_fm5_Click);
            // 
            // dateTimePicker_Slide_Record
            // 
            this.dateTimePicker_Slide_Record.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker_Slide_Record.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_Slide_Record.Location = new System.Drawing.Point(847, 179);
            this.dateTimePicker_Slide_Record.Name = "dateTimePicker_Slide_Record";
            this.dateTimePicker_Slide_Record.Size = new System.Drawing.Size(126, 22);
            this.dateTimePicker_Slide_Record.TabIndex = 74;
            this.dateTimePicker_Slide_Record.ValueChanged += new System.EventHandler(this.dateTimePicker_Slide_Record_ValueChanged);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(39, 451);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 75;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // lbl_top_insert_SlideRecord
            // 
            this.lbl_top_insert_SlideRecord.AutoSize = true;
            this.lbl_top_insert_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_insert_SlideRecord.Location = new System.Drawing.Point(371, 9);
            this.lbl_top_insert_SlideRecord.Name = "lbl_top_insert_SlideRecord";
            this.lbl_top_insert_SlideRecord.Size = new System.Drawing.Size(290, 29);
            this.lbl_top_insert_SlideRecord.TabIndex = 93;
            this.lbl_top_insert_SlideRecord.Text = "Insert Slide And Record";
            // 
            // Form_Slide_Record_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.lbl_top_insert_SlideRecord);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.dateTimePicker_Slide_Record);
            this.Controls.Add(this.comboBox_intake_select_Slide_Record);
            this.Controls.Add(this.txt_insert_recordlink_Slide_Record);
            this.Controls.Add(this.lbl_recordlink_Slide_Record);
            this.Controls.Add(this.txt_insert_slidelink_Slide_Record);
            this.Controls.Add(this.lbl_slidelink_Slide_Record);
            this.Controls.Add(this.txt_insert_date_Slide_Record);
            this.Controls.Add(this.lbl_date_Slide_Record);
            this.Controls.Add(this.txt_insert_course_id_Slide_Record);
            this.Controls.Add(this.lbl_intake_Slide_Record_select);
            this.Controls.Add(this.txt_insert_Slide_Record_intake);
            this.Controls.Add(this.lbl_intake_Slide_Record);
            this.Controls.Add(this.txt_insert_section_Slide_Record);
            this.Controls.Add(this.lbl_sec_Slide_Record);
            this.Controls.Add(this.btn_insert_Slide_Record);
            this.Controls.Add(this.lbl_course_id_Slide_Record);
            this.Controls.Add(this.btn_back_fm5);
            this.DoubleBuffered = true;
            this.Name = "Form_Slide_Record_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_Slide_Record_admin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_intake_select_Slide_Record;
        private System.Windows.Forms.TextBox txt_insert_recordlink_Slide_Record;
        private System.Windows.Forms.Label lbl_recordlink_Slide_Record;
        private System.Windows.Forms.TextBox txt_insert_slidelink_Slide_Record;
        private System.Windows.Forms.Label lbl_slidelink_Slide_Record;
        private System.Windows.Forms.TextBox txt_insert_date_Slide_Record;
        private System.Windows.Forms.Label lbl_date_Slide_Record;
        private System.Windows.Forms.TextBox txt_insert_course_id_Slide_Record;
        private System.Windows.Forms.Label lbl_intake_Slide_Record_select;
        private System.Windows.Forms.TextBox txt_insert_Slide_Record_intake;
        private System.Windows.Forms.Label lbl_intake_Slide_Record;
        private System.Windows.Forms.TextBox txt_insert_section_Slide_Record;
        private System.Windows.Forms.Label lbl_sec_Slide_Record;
        private System.Windows.Forms.Button btn_insert_Slide_Record;
        private System.Windows.Forms.Label lbl_course_id_Slide_Record;
        private System.Windows.Forms.Button btn_back_fm5;
        private System.Windows.Forms.DateTimePicker dateTimePicker_Slide_Record;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Label lbl_top_insert_SlideRecord;
    }
}