﻿
namespace smart_department
{
    partial class form_admin_update_routine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_admin_update_routine));
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.btn_admin_update_routine_deleteGo = new System.Windows.Forms.Button();
            this.lbl_top_admin_update_Routine = new System.Windows.Forms.Label();
            this.bnt_admin_update_routine_go = new System.Windows.Forms.Button();
            this.lbl_admin_update_select_intake_routine = new System.Windows.Forms.Label();
            this.comboBox_admin_update_routine_intake_select = new System.Windows.Forms.ComboBox();
            this.dataGridView_admin_update_routine = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_routine)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(910, 455);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 154;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(32, 455);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 153;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // btn_admin_update_routine_deleteGo
            // 
            this.btn_admin_update_routine_deleteGo.BackColor = System.Drawing.Color.Red;
            this.btn_admin_update_routine_deleteGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_routine_deleteGo.Location = new System.Drawing.Point(550, 400);
            this.btn_admin_update_routine_deleteGo.Name = "btn_admin_update_routine_deleteGo";
            this.btn_admin_update_routine_deleteGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_routine_deleteGo.TabIndex = 152;
            this.btn_admin_update_routine_deleteGo.Text = "DELETE";
            this.btn_admin_update_routine_deleteGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_routine_deleteGo.Click += new System.EventHandler(this.btn_admin_update_routine_deleteGo_Click);
            // 
            // lbl_top_admin_update_Routine
            // 
            this.lbl_top_admin_update_Routine.AutoSize = true;
            this.lbl_top_admin_update_Routine.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_admin_update_Routine.Location = new System.Drawing.Point(441, 11);
            this.lbl_top_admin_update_Routine.Name = "lbl_top_admin_update_Routine";
            this.lbl_top_admin_update_Routine.Size = new System.Drawing.Size(103, 29);
            this.lbl_top_admin_update_Routine.TabIndex = 150;
            this.lbl_top_admin_update_Routine.Text = "Routine";
            // 
            // bnt_admin_update_routine_go
            // 
            this.bnt_admin_update_routine_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_admin_update_routine_go.Location = new System.Drawing.Point(431, 414);
            this.bnt_admin_update_routine_go.Name = "bnt_admin_update_routine_go";
            this.bnt_admin_update_routine_go.Size = new System.Drawing.Size(50, 28);
            this.bnt_admin_update_routine_go.TabIndex = 149;
            this.bnt_admin_update_routine_go.Text = "GO";
            this.bnt_admin_update_routine_go.UseVisualStyleBackColor = true;
            this.bnt_admin_update_routine_go.Click += new System.EventHandler(this.bnt_admin_update_routine_go_Click);
            // 
            // lbl_admin_update_select_intake_routine
            // 
            this.lbl_admin_update_select_intake_routine.AutoSize = true;
            this.lbl_admin_update_select_intake_routine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_select_intake_routine.Location = new System.Drawing.Point(343, 336);
            this.lbl_admin_update_select_intake_routine.Name = "lbl_admin_update_select_intake_routine";
            this.lbl_admin_update_select_intake_routine.Size = new System.Drawing.Size(138, 25);
            this.lbl_admin_update_select_intake_routine.TabIndex = 148;
            this.lbl_admin_update_select_intake_routine.Text = "Select Intake";
            // 
            // comboBox_admin_update_routine_intake_select
            // 
            this.comboBox_admin_update_routine_intake_select.FormattingEnabled = true;
            this.comboBox_admin_update_routine_intake_select.Location = new System.Drawing.Point(345, 367);
            this.comboBox_admin_update_routine_intake_select.Name = "comboBox_admin_update_routine_intake_select";
            this.comboBox_admin_update_routine_intake_select.Size = new System.Drawing.Size(136, 24);
            this.comboBox_admin_update_routine_intake_select.TabIndex = 147;
            // 
            // dataGridView_admin_update_routine
            // 
            this.dataGridView_admin_update_routine.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_admin_update_routine.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_admin_update_routine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_admin_update_routine.Location = new System.Drawing.Point(30, 52);
            this.dataGridView_admin_update_routine.Name = "dataGridView_admin_update_routine";
            this.dataGridView_admin_update_routine.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView_admin_update_routine.RowHeadersVisible = false;
            this.dataGridView_admin_update_routine.RowHeadersWidth = 51;
            this.dataGridView_admin_update_routine.RowTemplate.Height = 24;
            this.dataGridView_admin_update_routine.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_admin_update_routine.Size = new System.Drawing.Size(956, 255);
            this.dataGridView_admin_update_routine.TabIndex = 155;
            this.dataGridView_admin_update_routine.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_admin_update_routine_CellContentClick);
            // 
            // form_admin_update_routine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.dataGridView_admin_update_routine);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.btn_admin_update_routine_deleteGo);
            this.Controls.Add(this.lbl_top_admin_update_Routine);
            this.Controls.Add(this.bnt_admin_update_routine_go);
            this.Controls.Add(this.lbl_admin_update_select_intake_routine);
            this.Controls.Add(this.comboBox_admin_update_routine_intake_select);
            this.DoubleBuffered = true;
            this.Name = "form_admin_update_routine";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_routine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_back_fm12_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Button btn_admin_update_routine_deleteGo;
        private System.Windows.Forms.Label lbl_top_admin_update_Routine;
        private System.Windows.Forms.Button bnt_admin_update_routine_go;
        private System.Windows.Forms.Label lbl_admin_update_select_intake_routine;
        private System.Windows.Forms.ComboBox comboBox_admin_update_routine_intake_select;
        private System.Windows.Forms.DataGridView dataGridView_admin_update_routine;
    }
}