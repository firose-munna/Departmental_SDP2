﻿
namespace smart_department
{
    partial class Form_admin_update_classlink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_admin_update_classlink));
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.btn_admin_update_classlink_deleteGo = new System.Windows.Forms.Button();
            this.btn_admin_update_classlink_updateGo = new System.Windows.Forms.Button();
            this.lbl_top_admin_update_classlink = new System.Windows.Forms.Label();
            this.bnt_admin_update_classlink_go = new System.Windows.Forms.Button();
            this.lbl_admin_update_select_intake_classlink = new System.Windows.Forms.Label();
            this.comboBox_admin_update_classlink_intake_select = new System.Windows.Forms.ComboBox();
            this.txt_admin_update_classlink_intake = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_intake_classlink = new System.Windows.Forms.Label();
            this.dataGridView_admin_update_classlink = new System.Windows.Forms.DataGridView();
            this.txt_admin_update_classlink_google_code = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_classlink_google_code = new System.Windows.Forms.Label();
            this.txt_admin_update_classlink_link = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_classlink_link = new System.Windows.Forms.Label();
            this.txt_admin_update_classlink_course_id = new System.Windows.Forms.TextBox();
            this.txt_admin_update_classlink_sec = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_classlink_sec = new System.Windows.Forms.Label();
            this.lbl_admin_update_classlink_course_id = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_classlink)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(910, 453);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 135;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(32, 453);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 134;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // btn_admin_update_classlink_deleteGo
            // 
            this.btn_admin_update_classlink_deleteGo.BackColor = System.Drawing.Color.Red;
            this.btn_admin_update_classlink_deleteGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_classlink_deleteGo.Location = new System.Drawing.Point(766, 391);
            this.btn_admin_update_classlink_deleteGo.Name = "btn_admin_update_classlink_deleteGo";
            this.btn_admin_update_classlink_deleteGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_classlink_deleteGo.TabIndex = 133;
            this.btn_admin_update_classlink_deleteGo.Text = "DELETE";
            this.btn_admin_update_classlink_deleteGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_classlink_deleteGo.Click += new System.EventHandler(this.btn_admin_update_classlink_deleteGo_Click);
            // 
            // btn_admin_update_classlink_updateGo
            // 
            this.btn_admin_update_classlink_updateGo.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_admin_update_classlink_updateGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_classlink_updateGo.Location = new System.Drawing.Point(766, 441);
            this.btn_admin_update_classlink_updateGo.Name = "btn_admin_update_classlink_updateGo";
            this.btn_admin_update_classlink_updateGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_classlink_updateGo.TabIndex = 132;
            this.btn_admin_update_classlink_updateGo.Text = "UPDATE";
            this.btn_admin_update_classlink_updateGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_classlink_updateGo.Click += new System.EventHandler(this.btn_admin_update_classlink_updateGo_Click);
            // 
            // lbl_top_admin_update_classlink
            // 
            this.lbl_top_admin_update_classlink.AutoSize = true;
            this.lbl_top_admin_update_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_admin_update_classlink.Location = new System.Drawing.Point(441, 9);
            this.lbl_top_admin_update_classlink.Name = "lbl_top_admin_update_classlink";
            this.lbl_top_admin_update_classlink.Size = new System.Drawing.Size(133, 29);
            this.lbl_top_admin_update_classlink.TabIndex = 129;
            this.lbl_top_admin_update_classlink.Text = "Class Link";
            // 
            // bnt_admin_update_classlink_go
            // 
            this.bnt_admin_update_classlink_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_admin_update_classlink_go.Location = new System.Drawing.Point(126, 366);
            this.bnt_admin_update_classlink_go.Name = "bnt_admin_update_classlink_go";
            this.bnt_admin_update_classlink_go.Size = new System.Drawing.Size(50, 28);
            this.bnt_admin_update_classlink_go.TabIndex = 126;
            this.bnt_admin_update_classlink_go.Text = "GO";
            this.bnt_admin_update_classlink_go.UseVisualStyleBackColor = true;
            this.bnt_admin_update_classlink_go.Click += new System.EventHandler(this.bnt_admin_update_classlink_go_Click);
            // 
            // lbl_admin_update_select_intake_classlink
            // 
            this.lbl_admin_update_select_intake_classlink.AutoSize = true;
            this.lbl_admin_update_select_intake_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_select_intake_classlink.Location = new System.Drawing.Point(38, 288);
            this.lbl_admin_update_select_intake_classlink.Name = "lbl_admin_update_select_intake_classlink";
            this.lbl_admin_update_select_intake_classlink.Size = new System.Drawing.Size(138, 25);
            this.lbl_admin_update_select_intake_classlink.TabIndex = 125;
            this.lbl_admin_update_select_intake_classlink.Text = "Select Intake";
            // 
            // comboBox_admin_update_classlink_intake_select
            // 
            this.comboBox_admin_update_classlink_intake_select.FormattingEnabled = true;
            this.comboBox_admin_update_classlink_intake_select.Location = new System.Drawing.Point(40, 319);
            this.comboBox_admin_update_classlink_intake_select.Name = "comboBox_admin_update_classlink_intake_select";
            this.comboBox_admin_update_classlink_intake_select.Size = new System.Drawing.Size(136, 24);
            this.comboBox_admin_update_classlink_intake_select.TabIndex = 124;
            // 
            // txt_admin_update_classlink_intake
            // 
            this.txt_admin_update_classlink_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_classlink_intake.Location = new System.Drawing.Point(247, 316);
            this.txt_admin_update_classlink_intake.Name = "txt_admin_update_classlink_intake";
            this.txt_admin_update_classlink_intake.Size = new System.Drawing.Size(127, 30);
            this.txt_admin_update_classlink_intake.TabIndex = 123;
            // 
            // lbl_admin_update_intake_classlink
            // 
            this.lbl_admin_update_intake_classlink.AutoSize = true;
            this.lbl_admin_update_intake_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_intake_classlink.Location = new System.Drawing.Point(244, 288);
            this.lbl_admin_update_intake_classlink.Name = "lbl_admin_update_intake_classlink";
            this.lbl_admin_update_intake_classlink.Size = new System.Drawing.Size(71, 25);
            this.lbl_admin_update_intake_classlink.TabIndex = 122;
            this.lbl_admin_update_intake_classlink.Text = "Intake";
            // 
            // dataGridView_admin_update_classlink
            // 
            this.dataGridView_admin_update_classlink.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_admin_update_classlink.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_admin_update_classlink.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_admin_update_classlink.Location = new System.Drawing.Point(29, 54);
            this.dataGridView_admin_update_classlink.Name = "dataGridView_admin_update_classlink";
            this.dataGridView_admin_update_classlink.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView_admin_update_classlink.RowHeadersVisible = false;
            this.dataGridView_admin_update_classlink.RowHeadersWidth = 51;
            this.dataGridView_admin_update_classlink.RowTemplate.Height = 24;
            this.dataGridView_admin_update_classlink.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_admin_update_classlink.Size = new System.Drawing.Size(956, 219);
            this.dataGridView_admin_update_classlink.TabIndex = 121;
            this.dataGridView_admin_update_classlink.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_admin_update_classlink_CellContentClick);
            // 
            // txt_admin_update_classlink_google_code
            // 
            this.txt_admin_update_classlink_google_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_classlink_google_code.Location = new System.Drawing.Point(432, 384);
            this.txt_admin_update_classlink_google_code.Name = "txt_admin_update_classlink_google_code";
            this.txt_admin_update_classlink_google_code.Size = new System.Drawing.Size(294, 30);
            this.txt_admin_update_classlink_google_code.TabIndex = 143;
            // 
            // lbl_admin_update_classlink_google_code
            // 
            this.lbl_admin_update_classlink_google_code.AutoSize = true;
            this.lbl_admin_update_classlink_google_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_classlink_google_code.Location = new System.Drawing.Point(432, 356);
            this.lbl_admin_update_classlink_google_code.Name = "lbl_admin_update_classlink_google_code";
            this.lbl_admin_update_classlink_google_code.Size = new System.Drawing.Size(248, 25);
            this.lbl_admin_update_classlink_google_code.TabIndex = 142;
            this.lbl_admin_update_classlink_google_code.Text = "Google Classroom Code";
            // 
            // txt_admin_update_classlink_link
            // 
            this.txt_admin_update_classlink_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_classlink_link.Location = new System.Drawing.Point(432, 452);
            this.txt_admin_update_classlink_link.Name = "txt_admin_update_classlink_link";
            this.txt_admin_update_classlink_link.Size = new System.Drawing.Size(294, 30);
            this.txt_admin_update_classlink_link.TabIndex = 141;
            // 
            // lbl_admin_update_classlink_link
            // 
            this.lbl_admin_update_classlink_link.AutoSize = true;
            this.lbl_admin_update_classlink_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_classlink_link.Location = new System.Drawing.Point(432, 424);
            this.lbl_admin_update_classlink_link.Name = "lbl_admin_update_classlink_link";
            this.lbl_admin_update_classlink_link.Size = new System.Drawing.Size(113, 25);
            this.lbl_admin_update_classlink_link.TabIndex = 140;
            this.lbl_admin_update_classlink_link.Text = "Class Link";
            // 
            // txt_admin_update_classlink_course_id
            // 
            this.txt_admin_update_classlink_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_classlink_course_id.Location = new System.Drawing.Point(431, 316);
            this.txt_admin_update_classlink_course_id.Name = "txt_admin_update_classlink_course_id";
            this.txt_admin_update_classlink_course_id.Size = new System.Drawing.Size(294, 30);
            this.txt_admin_update_classlink_course_id.TabIndex = 139;
            // 
            // txt_admin_update_classlink_sec
            // 
            this.txt_admin_update_classlink_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_classlink_sec.Location = new System.Drawing.Point(247, 395);
            this.txt_admin_update_classlink_sec.Name = "txt_admin_update_classlink_sec";
            this.txt_admin_update_classlink_sec.Size = new System.Drawing.Size(127, 30);
            this.txt_admin_update_classlink_sec.TabIndex = 138;
            // 
            // lbl_admin_update_classlink_sec
            // 
            this.lbl_admin_update_classlink_sec.AutoSize = true;
            this.lbl_admin_update_classlink_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_classlink_sec.Location = new System.Drawing.Point(244, 365);
            this.lbl_admin_update_classlink_sec.Name = "lbl_admin_update_classlink_sec";
            this.lbl_admin_update_classlink_sec.Size = new System.Drawing.Size(85, 25);
            this.lbl_admin_update_classlink_sec.TabIndex = 137;
            this.lbl_admin_update_classlink_sec.Text = "Section";
            // 
            // lbl_admin_update_classlink_course_id
            // 
            this.lbl_admin_update_classlink_course_id.AutoSize = true;
            this.lbl_admin_update_classlink_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_classlink_course_id.Location = new System.Drawing.Point(431, 288);
            this.lbl_admin_update_classlink_course_id.Name = "lbl_admin_update_classlink_course_id";
            this.lbl_admin_update_classlink_course_id.Size = new System.Drawing.Size(109, 25);
            this.lbl_admin_update_classlink_course_id.TabIndex = 136;
            this.lbl_admin_update_classlink_course_id.Text = "Course ID";
            // 
            // Form_admin_update_classlink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.txt_admin_update_classlink_google_code);
            this.Controls.Add(this.lbl_admin_update_classlink_google_code);
            this.Controls.Add(this.txt_admin_update_classlink_link);
            this.Controls.Add(this.lbl_admin_update_classlink_link);
            this.Controls.Add(this.txt_admin_update_classlink_course_id);
            this.Controls.Add(this.txt_admin_update_classlink_sec);
            this.Controls.Add(this.lbl_admin_update_classlink_sec);
            this.Controls.Add(this.lbl_admin_update_classlink_course_id);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.btn_admin_update_classlink_deleteGo);
            this.Controls.Add(this.btn_admin_update_classlink_updateGo);
            this.Controls.Add(this.lbl_top_admin_update_classlink);
            this.Controls.Add(this.bnt_admin_update_classlink_go);
            this.Controls.Add(this.lbl_admin_update_select_intake_classlink);
            this.Controls.Add(this.comboBox_admin_update_classlink_intake_select);
            this.Controls.Add(this.txt_admin_update_classlink_intake);
            this.Controls.Add(this.lbl_admin_update_intake_classlink);
            this.Controls.Add(this.dataGridView_admin_update_classlink);
            this.DoubleBuffered = true;
            this.Name = "Form_admin_update_classlink";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_admin_update_classlink_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_classlink)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_back_fm12_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Button btn_admin_update_classlink_deleteGo;
        private System.Windows.Forms.Button btn_admin_update_classlink_updateGo;
        private System.Windows.Forms.Label lbl_top_admin_update_classlink;
        private System.Windows.Forms.Button bnt_admin_update_classlink_go;
        private System.Windows.Forms.Label lbl_admin_update_select_intake_classlink;
        private System.Windows.Forms.ComboBox comboBox_admin_update_classlink_intake_select;
        private System.Windows.Forms.TextBox txt_admin_update_classlink_intake;
        private System.Windows.Forms.Label lbl_admin_update_intake_classlink;
        private System.Windows.Forms.DataGridView dataGridView_admin_update_classlink;
        private System.Windows.Forms.TextBox txt_admin_update_classlink_google_code;
        private System.Windows.Forms.Label lbl_admin_update_classlink_google_code;
        private System.Windows.Forms.TextBox txt_admin_update_classlink_link;
        private System.Windows.Forms.Label lbl_admin_update_classlink_link;
        private System.Windows.Forms.TextBox txt_admin_update_classlink_course_id;
        private System.Windows.Forms.TextBox txt_admin_update_classlink_sec;
        private System.Windows.Forms.Label lbl_admin_update_classlink_sec;
        private System.Windows.Forms.Label lbl_admin_update_classlink_course_id;
    }
}