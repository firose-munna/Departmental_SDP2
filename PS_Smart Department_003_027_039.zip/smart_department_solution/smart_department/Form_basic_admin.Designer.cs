﻿
namespace smart_department
{
    partial class Form_basic_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_basic_admin));
            this.lbl_intake_basic = new System.Windows.Forms.Label();
            this.txt_insert_basic_intake = new System.Windows.Forms.TextBox();
            this.btn_insert_basic_intake = new System.Windows.Forms.Button();
            this.btn_insert_basic_course_id_name = new System.Windows.Forms.Button();
            this.txt_insert_basic_course_id = new System.Windows.Forms.TextBox();
            this.lbl_course_id_basic = new System.Windows.Forms.Label();
            this.txt_insert_basic_course_name = new System.Windows.Forms.TextBox();
            this.lbl_course_name_basic = new System.Windows.Forms.Label();
            this.btn_back_fm5 = new System.Windows.Forms.Button();
            this.txt_insert_basic_intake2 = new System.Windows.Forms.TextBox();
            this.lbl_intake_basic2 = new System.Windows.Forms.Label();
            this.comboBox_intake_select = new System.Windows.Forms.ComboBox();
            this.lbl_intake_basic2_select = new System.Windows.Forms.Label();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.lbl_top_insert_basic = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_intake_basic
            // 
            this.lbl_intake_basic.AutoSize = true;
            this.lbl_intake_basic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_basic.Location = new System.Drawing.Point(110, 156);
            this.lbl_intake_basic.Name = "lbl_intake_basic";
            this.lbl_intake_basic.Size = new System.Drawing.Size(71, 25);
            this.lbl_intake_basic.TabIndex = 0;
            this.lbl_intake_basic.Text = "Intake";
            // 
            // txt_insert_basic_intake
            // 
            this.txt_insert_basic_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_basic_intake.Location = new System.Drawing.Point(113, 184);
            this.txt_insert_basic_intake.Name = "txt_insert_basic_intake";
            this.txt_insert_basic_intake.Size = new System.Drawing.Size(174, 30);
            this.txt_insert_basic_intake.TabIndex = 7;
            // 
            // btn_insert_basic_intake
            // 
            this.btn_insert_basic_intake.Location = new System.Drawing.Point(343, 184);
            this.btn_insert_basic_intake.Name = "btn_insert_basic_intake";
            this.btn_insert_basic_intake.Size = new System.Drawing.Size(59, 30);
            this.btn_insert_basic_intake.TabIndex = 8;
            this.btn_insert_basic_intake.Text = "GO";
            this.btn_insert_basic_intake.UseVisualStyleBackColor = true;
            this.btn_insert_basic_intake.Click += new System.EventHandler(this.btn_insert_basic_intake_Click);
            // 
            // btn_insert_basic_course_id_name
            // 
            this.btn_insert_basic_course_id_name.Location = new System.Drawing.Point(840, 328);
            this.btn_insert_basic_course_id_name.Name = "btn_insert_basic_course_id_name";
            this.btn_insert_basic_course_id_name.Size = new System.Drawing.Size(59, 30);
            this.btn_insert_basic_course_id_name.TabIndex = 11;
            this.btn_insert_basic_course_id_name.Text = "GO";
            this.btn_insert_basic_course_id_name.UseVisualStyleBackColor = true;
            this.btn_insert_basic_course_id_name.Click += new System.EventHandler(this.btn_insert_basic_course_id_Click);
            // 
            // txt_insert_basic_course_id
            // 
            this.txt_insert_basic_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_basic_course_id.Location = new System.Drawing.Point(600, 256);
            this.txt_insert_basic_course_id.Name = "txt_insert_basic_course_id";
            this.txt_insert_basic_course_id.Size = new System.Drawing.Size(174, 30);
            this.txt_insert_basic_course_id.TabIndex = 10;
            // 
            // lbl_course_id_basic
            // 
            this.lbl_course_id_basic.AutoSize = true;
            this.lbl_course_id_basic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course_id_basic.Location = new System.Drawing.Point(597, 228);
            this.lbl_course_id_basic.Name = "lbl_course_id_basic";
            this.lbl_course_id_basic.Size = new System.Drawing.Size(109, 25);
            this.lbl_course_id_basic.TabIndex = 9;
            this.lbl_course_id_basic.Text = "Course ID";
            // 
            // txt_insert_basic_course_name
            // 
            this.txt_insert_basic_course_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_basic_course_name.Location = new System.Drawing.Point(602, 328);
            this.txt_insert_basic_course_name.Name = "txt_insert_basic_course_name";
            this.txt_insert_basic_course_name.Size = new System.Drawing.Size(174, 30);
            this.txt_insert_basic_course_name.TabIndex = 13;
            // 
            // lbl_course_name_basic
            // 
            this.lbl_course_name_basic.AutoSize = true;
            this.lbl_course_name_basic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course_name_basic.Location = new System.Drawing.Point(599, 300);
            this.lbl_course_name_basic.Name = "lbl_course_name_basic";
            this.lbl_course_name_basic.Size = new System.Drawing.Size(144, 25);
            this.lbl_course_name_basic.TabIndex = 12;
            this.lbl_course_name_basic.Text = "Course Name";
            // 
            // btn_back_fm5
            // 
            this.btn_back_fm5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm5.Location = new System.Drawing.Point(903, 449);
            this.btn_back_fm5.Name = "btn_back_fm5";
            this.btn_back_fm5.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm5.TabIndex = 14;
            this.btn_back_fm5.Text = "BACK";
            this.btn_back_fm5.UseVisualStyleBackColor = false;
            this.btn_back_fm5.Click += new System.EventHandler(this.btn_back_fm5_Click);
            // 
            // txt_insert_basic_intake2
            // 
            this.txt_insert_basic_intake2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_basic_intake2.Location = new System.Drawing.Point(600, 187);
            this.txt_insert_basic_intake2.Name = "txt_insert_basic_intake2";
            this.txt_insert_basic_intake2.Size = new System.Drawing.Size(174, 30);
            this.txt_insert_basic_intake2.TabIndex = 16;
            // 
            // lbl_intake_basic2
            // 
            this.lbl_intake_basic2.AutoSize = true;
            this.lbl_intake_basic2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_basic2.Location = new System.Drawing.Point(597, 159);
            this.lbl_intake_basic2.Name = "lbl_intake_basic2";
            this.lbl_intake_basic2.Size = new System.Drawing.Size(71, 25);
            this.lbl_intake_basic2.TabIndex = 15;
            this.lbl_intake_basic2.Text = "Intake";
            // 
            // comboBox_intake_select
            // 
            this.comboBox_intake_select.FormattingEnabled = true;
            this.comboBox_intake_select.Location = new System.Drawing.Point(816, 190);
            this.comboBox_intake_select.Name = "comboBox_intake_select";
            this.comboBox_intake_select.Size = new System.Drawing.Size(83, 24);
            this.comboBox_intake_select.TabIndex = 17;
            this.comboBox_intake_select.SelectedIndexChanged += new System.EventHandler(this.comboBox_intake_select_SelectedIndexChanged);
            // 
            // lbl_intake_basic2_select
            // 
            this.lbl_intake_basic2_select.AutoSize = true;
            this.lbl_intake_basic2_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_basic2_select.Location = new System.Drawing.Point(816, 159);
            this.lbl_intake_basic2_select.Name = "lbl_intake_basic2_select";
            this.lbl_intake_basic2_select.Size = new System.Drawing.Size(73, 25);
            this.lbl_intake_basic2_select.TabIndex = 18;
            this.lbl_intake_basic2_select.Text = "Select";
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(36, 452);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 21;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // lbl_top_insert_basic
            // 
            this.lbl_top_insert_basic.AutoSize = true;
            this.lbl_top_insert_basic.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_insert_basic.Location = new System.Drawing.Point(406, 9);
            this.lbl_top_insert_basic.Name = "lbl_top_insert_basic";
            this.lbl_top_insert_basic.Size = new System.Drawing.Size(209, 29);
            this.lbl_top_insert_basic.TabIndex = 89;
            this.lbl_top_insert_basic.Text = "Insert Basic Data";
            // 
            // Form_basic_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.lbl_top_insert_basic);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.lbl_intake_basic2_select);
            this.Controls.Add(this.comboBox_intake_select);
            this.Controls.Add(this.txt_insert_basic_intake2);
            this.Controls.Add(this.lbl_intake_basic2);
            this.Controls.Add(this.btn_back_fm5);
            this.Controls.Add(this.txt_insert_basic_course_name);
            this.Controls.Add(this.lbl_course_name_basic);
            this.Controls.Add(this.btn_insert_basic_course_id_name);
            this.Controls.Add(this.txt_insert_basic_course_id);
            this.Controls.Add(this.lbl_course_id_basic);
            this.Controls.Add(this.btn_insert_basic_intake);
            this.Controls.Add(this.txt_insert_basic_intake);
            this.Controls.Add(this.lbl_intake_basic);
            this.DoubleBuffered = true;
            this.Name = "Form_basic_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_basic_admin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_intake_basic;
        private System.Windows.Forms.TextBox txt_insert_basic_intake;
        private System.Windows.Forms.Button btn_insert_basic_intake;
        private System.Windows.Forms.Button btn_insert_basic_course_id_name;
        private System.Windows.Forms.TextBox txt_insert_basic_course_id;
        private System.Windows.Forms.Label lbl_course_id_basic;
        private System.Windows.Forms.TextBox txt_insert_basic_course_name;
        private System.Windows.Forms.Label lbl_course_name_basic;
        private System.Windows.Forms.Button btn_back_fm5;
        private System.Windows.Forms.TextBox txt_insert_basic_intake2;
        private System.Windows.Forms.Label lbl_intake_basic2;
        private System.Windows.Forms.ComboBox comboBox_intake_select;
        private System.Windows.Forms.Label lbl_intake_basic2_select;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Label lbl_top_insert_basic;
    }
}