﻿
namespace smart_department
{
    partial class Form_admin_update_SlideRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_admin_update_SlideRecord));
            this.txt_admin_update_SlideRecord_course_id = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_SlideRecord_course_id = new System.Windows.Forms.Label();
            this.txt_admin_update_SlideRecord_slidelink = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_SlideRecord_slidelink = new System.Windows.Forms.Label();
            this.txt_admin_update_SlideRecord_recordlink = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_SlideRecord_recordlink = new System.Windows.Forms.Label();
            this.txt_admin_update_SlideRecord_Perform_date = new System.Windows.Forms.TextBox();
            this.txt_admin_update_SlideRecord_sec = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_SlideRecord_sec = new System.Windows.Forms.Label();
            this.lbl_admin_update_SlideRecord_Perform_date = new System.Windows.Forms.Label();
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.btn_admin_update_SlideRecord_deleteGo = new System.Windows.Forms.Button();
            this.btn_admin_update_SlideRecord_updateGo = new System.Windows.Forms.Button();
            this.lbl_top_admin_update_SlideRecord = new System.Windows.Forms.Label();
            this.bnt_admin_update_SlideRecord_go = new System.Windows.Forms.Button();
            this.lbl_admin_update_select_intake_SlideRecord = new System.Windows.Forms.Label();
            this.comboBox_admin_update_SlideRecord_intake_select = new System.Windows.Forms.ComboBox();
            this.txt_admin_update_SlideRecord_intake = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_intake_SlideRecord = new System.Windows.Forms.Label();
            this.dataGridView_admin_update_SlideRecord = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_SlideRecord)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_admin_update_SlideRecord_course_id
            // 
            this.txt_admin_update_SlideRecord_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_SlideRecord_course_id.Location = new System.Drawing.Point(432, 316);
            this.txt_admin_update_SlideRecord_course_id.Name = "txt_admin_update_SlideRecord_course_id";
            this.txt_admin_update_SlideRecord_course_id.Size = new System.Drawing.Size(294, 30);
            this.txt_admin_update_SlideRecord_course_id.TabIndex = 187;
            // 
            // lbl_admin_update_SlideRecord_course_id
            // 
            this.lbl_admin_update_SlideRecord_course_id.AutoSize = true;
            this.lbl_admin_update_SlideRecord_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_SlideRecord_course_id.Location = new System.Drawing.Point(432, 288);
            this.lbl_admin_update_SlideRecord_course_id.Name = "lbl_admin_update_SlideRecord_course_id";
            this.lbl_admin_update_SlideRecord_course_id.Size = new System.Drawing.Size(109, 25);
            this.lbl_admin_update_SlideRecord_course_id.TabIndex = 186;
            this.lbl_admin_update_SlideRecord_course_id.Text = "Course ID";
            // 
            // txt_admin_update_SlideRecord_slidelink
            // 
            this.txt_admin_update_SlideRecord_slidelink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_SlideRecord_slidelink.Location = new System.Drawing.Point(432, 384);
            this.txt_admin_update_SlideRecord_slidelink.Name = "txt_admin_update_SlideRecord_slidelink";
            this.txt_admin_update_SlideRecord_slidelink.Size = new System.Drawing.Size(294, 30);
            this.txt_admin_update_SlideRecord_slidelink.TabIndex = 185;
            // 
            // lbl_admin_update_SlideRecord_slidelink
            // 
            this.lbl_admin_update_SlideRecord_slidelink.AutoSize = true;
            this.lbl_admin_update_SlideRecord_slidelink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_SlideRecord_slidelink.Location = new System.Drawing.Point(432, 356);
            this.lbl_admin_update_SlideRecord_slidelink.Name = "lbl_admin_update_SlideRecord_slidelink";
            this.lbl_admin_update_SlideRecord_slidelink.Size = new System.Drawing.Size(107, 25);
            this.lbl_admin_update_SlideRecord_slidelink.TabIndex = 184;
            this.lbl_admin_update_SlideRecord_slidelink.Text = "Slide Link";
            // 
            // txt_admin_update_SlideRecord_recordlink
            // 
            this.txt_admin_update_SlideRecord_recordlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_SlideRecord_recordlink.Location = new System.Drawing.Point(432, 452);
            this.txt_admin_update_SlideRecord_recordlink.Name = "txt_admin_update_SlideRecord_recordlink";
            this.txt_admin_update_SlideRecord_recordlink.Size = new System.Drawing.Size(294, 30);
            this.txt_admin_update_SlideRecord_recordlink.TabIndex = 183;
            // 
            // lbl_admin_update_SlideRecord_recordlink
            // 
            this.lbl_admin_update_SlideRecord_recordlink.AutoSize = true;
            this.lbl_admin_update_SlideRecord_recordlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_SlideRecord_recordlink.Location = new System.Drawing.Point(432, 424);
            this.lbl_admin_update_SlideRecord_recordlink.Name = "lbl_admin_update_SlideRecord_recordlink";
            this.lbl_admin_update_SlideRecord_recordlink.Size = new System.Drawing.Size(126, 25);
            this.lbl_admin_update_SlideRecord_recordlink.TabIndex = 182;
            this.lbl_admin_update_SlideRecord_recordlink.Text = "Record Link";
            // 
            // txt_admin_update_SlideRecord_Perform_date
            // 
            this.txt_admin_update_SlideRecord_Perform_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_SlideRecord_Perform_date.Location = new System.Drawing.Point(244, 452);
            this.txt_admin_update_SlideRecord_Perform_date.Name = "txt_admin_update_SlideRecord_Perform_date";
            this.txt_admin_update_SlideRecord_Perform_date.Size = new System.Drawing.Size(140, 30);
            this.txt_admin_update_SlideRecord_Perform_date.TabIndex = 181;
            // 
            // txt_admin_update_SlideRecord_sec
            // 
            this.txt_admin_update_SlideRecord_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_SlideRecord_sec.Location = new System.Drawing.Point(247, 386);
            this.txt_admin_update_SlideRecord_sec.Name = "txt_admin_update_SlideRecord_sec";
            this.txt_admin_update_SlideRecord_sec.Size = new System.Drawing.Size(137, 30);
            this.txt_admin_update_SlideRecord_sec.TabIndex = 180;
            // 
            // lbl_admin_update_SlideRecord_sec
            // 
            this.lbl_admin_update_SlideRecord_sec.AutoSize = true;
            this.lbl_admin_update_SlideRecord_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_SlideRecord_sec.Location = new System.Drawing.Point(244, 356);
            this.lbl_admin_update_SlideRecord_sec.Name = "lbl_admin_update_SlideRecord_sec";
            this.lbl_admin_update_SlideRecord_sec.Size = new System.Drawing.Size(85, 25);
            this.lbl_admin_update_SlideRecord_sec.TabIndex = 179;
            this.lbl_admin_update_SlideRecord_sec.Text = "Section";
            // 
            // lbl_admin_update_SlideRecord_Perform_date
            // 
            this.lbl_admin_update_SlideRecord_Perform_date.AutoSize = true;
            this.lbl_admin_update_SlideRecord_Perform_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_SlideRecord_Perform_date.Location = new System.Drawing.Point(244, 424);
            this.lbl_admin_update_SlideRecord_Perform_date.Name = "lbl_admin_update_SlideRecord_Perform_date";
            this.lbl_admin_update_SlideRecord_Perform_date.Size = new System.Drawing.Size(162, 25);
            this.lbl_admin_update_SlideRecord_Perform_date.TabIndex = 178;
            this.lbl_admin_update_SlideRecord_Perform_date.Text = "Performed Date";
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(910, 453);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 177;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(32, 453);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 176;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // btn_admin_update_SlideRecord_deleteGo
            // 
            this.btn_admin_update_SlideRecord_deleteGo.BackColor = System.Drawing.Color.Red;
            this.btn_admin_update_SlideRecord_deleteGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_SlideRecord_deleteGo.Location = new System.Drawing.Point(766, 391);
            this.btn_admin_update_SlideRecord_deleteGo.Name = "btn_admin_update_SlideRecord_deleteGo";
            this.btn_admin_update_SlideRecord_deleteGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_SlideRecord_deleteGo.TabIndex = 175;
            this.btn_admin_update_SlideRecord_deleteGo.Text = "DELETE";
            this.btn_admin_update_SlideRecord_deleteGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_SlideRecord_deleteGo.Click += new System.EventHandler(this.btn_admin_update_SlideRecord_deleteGo_Click);
            // 
            // btn_admin_update_SlideRecord_updateGo
            // 
            this.btn_admin_update_SlideRecord_updateGo.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_admin_update_SlideRecord_updateGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_SlideRecord_updateGo.Location = new System.Drawing.Point(766, 441);
            this.btn_admin_update_SlideRecord_updateGo.Name = "btn_admin_update_SlideRecord_updateGo";
            this.btn_admin_update_SlideRecord_updateGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_SlideRecord_updateGo.TabIndex = 174;
            this.btn_admin_update_SlideRecord_updateGo.Text = "UPDATE";
            this.btn_admin_update_SlideRecord_updateGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_SlideRecord_updateGo.Click += new System.EventHandler(this.btn_admin_update_SlideRecord_updateGo_Click);
            // 
            // lbl_top_admin_update_SlideRecord
            // 
            this.lbl_top_admin_update_SlideRecord.AutoSize = true;
            this.lbl_top_admin_update_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_admin_update_SlideRecord.Location = new System.Drawing.Point(356, 9);
            this.lbl_top_admin_update_SlideRecord.Name = "lbl_top_admin_update_SlideRecord";
            this.lbl_top_admin_update_SlideRecord.Size = new System.Drawing.Size(314, 29);
            this.lbl_top_admin_update_SlideRecord.TabIndex = 173;
            this.lbl_top_admin_update_SlideRecord.Text = "Slides and Class Records";
            // 
            // bnt_admin_update_SlideRecord_go
            // 
            this.bnt_admin_update_SlideRecord_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_admin_update_SlideRecord_go.Location = new System.Drawing.Point(126, 366);
            this.bnt_admin_update_SlideRecord_go.Name = "bnt_admin_update_SlideRecord_go";
            this.bnt_admin_update_SlideRecord_go.Size = new System.Drawing.Size(50, 28);
            this.bnt_admin_update_SlideRecord_go.TabIndex = 172;
            this.bnt_admin_update_SlideRecord_go.Text = "GO";
            this.bnt_admin_update_SlideRecord_go.UseVisualStyleBackColor = true;
            this.bnt_admin_update_SlideRecord_go.Click += new System.EventHandler(this.bnt_admin_update_SlideRecord_go_Click);
            // 
            // lbl_admin_update_select_intake_SlideRecord
            // 
            this.lbl_admin_update_select_intake_SlideRecord.AutoSize = true;
            this.lbl_admin_update_select_intake_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_select_intake_SlideRecord.Location = new System.Drawing.Point(38, 288);
            this.lbl_admin_update_select_intake_SlideRecord.Name = "lbl_admin_update_select_intake_SlideRecord";
            this.lbl_admin_update_select_intake_SlideRecord.Size = new System.Drawing.Size(138, 25);
            this.lbl_admin_update_select_intake_SlideRecord.TabIndex = 171;
            this.lbl_admin_update_select_intake_SlideRecord.Text = "Select Intake";
            // 
            // comboBox_admin_update_SlideRecord_intake_select
            // 
            this.comboBox_admin_update_SlideRecord_intake_select.FormattingEnabled = true;
            this.comboBox_admin_update_SlideRecord_intake_select.Location = new System.Drawing.Point(40, 319);
            this.comboBox_admin_update_SlideRecord_intake_select.Name = "comboBox_admin_update_SlideRecord_intake_select";
            this.comboBox_admin_update_SlideRecord_intake_select.Size = new System.Drawing.Size(136, 24);
            this.comboBox_admin_update_SlideRecord_intake_select.TabIndex = 170;
            // 
            // txt_admin_update_SlideRecord_intake
            // 
            this.txt_admin_update_SlideRecord_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_SlideRecord_intake.Location = new System.Drawing.Point(247, 316);
            this.txt_admin_update_SlideRecord_intake.Name = "txt_admin_update_SlideRecord_intake";
            this.txt_admin_update_SlideRecord_intake.Size = new System.Drawing.Size(137, 30);
            this.txt_admin_update_SlideRecord_intake.TabIndex = 169;
            // 
            // lbl_admin_update_intake_SlideRecord
            // 
            this.lbl_admin_update_intake_SlideRecord.AutoSize = true;
            this.lbl_admin_update_intake_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_intake_SlideRecord.Location = new System.Drawing.Point(244, 288);
            this.lbl_admin_update_intake_SlideRecord.Name = "lbl_admin_update_intake_SlideRecord";
            this.lbl_admin_update_intake_SlideRecord.Size = new System.Drawing.Size(71, 25);
            this.lbl_admin_update_intake_SlideRecord.TabIndex = 168;
            this.lbl_admin_update_intake_SlideRecord.Text = "Intake";
            // 
            // dataGridView_admin_update_SlideRecord
            // 
            this.dataGridView_admin_update_SlideRecord.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_admin_update_SlideRecord.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_admin_update_SlideRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_admin_update_SlideRecord.Location = new System.Drawing.Point(29, 54);
            this.dataGridView_admin_update_SlideRecord.Name = "dataGridView_admin_update_SlideRecord";
            this.dataGridView_admin_update_SlideRecord.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView_admin_update_SlideRecord.RowHeadersVisible = false;
            this.dataGridView_admin_update_SlideRecord.RowHeadersWidth = 51;
            this.dataGridView_admin_update_SlideRecord.RowTemplate.Height = 24;
            this.dataGridView_admin_update_SlideRecord.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_admin_update_SlideRecord.Size = new System.Drawing.Size(956, 219);
            this.dataGridView_admin_update_SlideRecord.TabIndex = 167;
            this.dataGridView_admin_update_SlideRecord.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_admin_update_SlideRecord_CellContentClick);
            // 
            // Form_admin_update_SlideRecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.txt_admin_update_SlideRecord_course_id);
            this.Controls.Add(this.lbl_admin_update_SlideRecord_course_id);
            this.Controls.Add(this.txt_admin_update_SlideRecord_slidelink);
            this.Controls.Add(this.lbl_admin_update_SlideRecord_slidelink);
            this.Controls.Add(this.txt_admin_update_SlideRecord_recordlink);
            this.Controls.Add(this.lbl_admin_update_SlideRecord_recordlink);
            this.Controls.Add(this.txt_admin_update_SlideRecord_Perform_date);
            this.Controls.Add(this.txt_admin_update_SlideRecord_sec);
            this.Controls.Add(this.lbl_admin_update_SlideRecord_sec);
            this.Controls.Add(this.lbl_admin_update_SlideRecord_Perform_date);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.btn_admin_update_SlideRecord_deleteGo);
            this.Controls.Add(this.btn_admin_update_SlideRecord_updateGo);
            this.Controls.Add(this.lbl_top_admin_update_SlideRecord);
            this.Controls.Add(this.bnt_admin_update_SlideRecord_go);
            this.Controls.Add(this.lbl_admin_update_select_intake_SlideRecord);
            this.Controls.Add(this.comboBox_admin_update_SlideRecord_intake_select);
            this.Controls.Add(this.txt_admin_update_SlideRecord_intake);
            this.Controls.Add(this.lbl_admin_update_intake_SlideRecord);
            this.Controls.Add(this.dataGridView_admin_update_SlideRecord);
            this.DoubleBuffered = true;
            this.Name = "Form_admin_update_SlideRecord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_SlideRecord)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_admin_update_SlideRecord_course_id;
        private System.Windows.Forms.Label lbl_admin_update_SlideRecord_course_id;
        private System.Windows.Forms.TextBox txt_admin_update_SlideRecord_slidelink;
        private System.Windows.Forms.Label lbl_admin_update_SlideRecord_slidelink;
        private System.Windows.Forms.TextBox txt_admin_update_SlideRecord_recordlink;
        private System.Windows.Forms.Label lbl_admin_update_SlideRecord_recordlink;
        private System.Windows.Forms.TextBox txt_admin_update_SlideRecord_Perform_date;
        private System.Windows.Forms.TextBox txt_admin_update_SlideRecord_sec;
        private System.Windows.Forms.Label lbl_admin_update_SlideRecord_sec;
        private System.Windows.Forms.Label lbl_admin_update_SlideRecord_Perform_date;
        private System.Windows.Forms.Button btn_back_fm12_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Button btn_admin_update_SlideRecord_deleteGo;
        private System.Windows.Forms.Button btn_admin_update_SlideRecord_updateGo;
        private System.Windows.Forms.Label lbl_top_admin_update_SlideRecord;
        private System.Windows.Forms.Button bnt_admin_update_SlideRecord_go;
        private System.Windows.Forms.Label lbl_admin_update_select_intake_SlideRecord;
        private System.Windows.Forms.ComboBox comboBox_admin_update_SlideRecord_intake_select;
        private System.Windows.Forms.TextBox txt_admin_update_SlideRecord_intake;
        private System.Windows.Forms.Label lbl_admin_update_intake_SlideRecord;
        private System.Windows.Forms.DataGridView dataGridView_admin_update_SlideRecord;
    }
}