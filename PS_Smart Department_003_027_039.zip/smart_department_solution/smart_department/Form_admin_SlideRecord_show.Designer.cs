﻿
namespace smart_department
{
    partial class Form_admin_SlideRecord_show
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_admin_SlideRecord_show));
            this.txt_show_SlideRecord_sec = new System.Windows.Forms.TextBox();
            this.lbl_sec_show_SlideRecord = new System.Windows.Forms.Label();
            this.bnt_show_SlideRecord_go = new System.Windows.Forms.Button();
            this.lbl_intake_SlideRecord_show_select = new System.Windows.Forms.Label();
            this.comboBox_intake_select_SlideRecord = new System.Windows.Forms.ComboBox();
            this.txt_show_SlideRecord_intake = new System.Windows.Forms.TextBox();
            this.lbl_intake_show_SlideRecord = new System.Windows.Forms.Label();
            this.dataGridView_SlideRecord_show_admin = new System.Windows.Forms.DataGridView();
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.txt_show_SlideRecord_date = new System.Windows.Forms.TextBox();
            this.lbl_date_show_SlideRecord = new System.Windows.Forms.Label();
            this.dateTimePicker_SlideRecord = new System.Windows.Forms.DateTimePicker();
            this.lbl_top_show_slideRecord = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_SlideRecord_show_admin)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_show_SlideRecord_sec
            // 
            this.txt_show_SlideRecord_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_show_SlideRecord_sec.Location = new System.Drawing.Point(40, 290);
            this.txt_show_SlideRecord_sec.Name = "txt_show_SlideRecord_sec";
            this.txt_show_SlideRecord_sec.Size = new System.Drawing.Size(174, 30);
            this.txt_show_SlideRecord_sec.TabIndex = 68;
            // 
            // lbl_sec_show_SlideRecord
            // 
            this.lbl_sec_show_SlideRecord.AutoSize = true;
            this.lbl_sec_show_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sec_show_SlideRecord.Location = new System.Drawing.Point(37, 262);
            this.lbl_sec_show_SlideRecord.Name = "lbl_sec_show_SlideRecord";
            this.lbl_sec_show_SlideRecord.Size = new System.Drawing.Size(85, 25);
            this.lbl_sec_show_SlideRecord.TabIndex = 67;
            this.lbl_sec_show_SlideRecord.Text = "Section";
            // 
            // bnt_show_SlideRecord_go
            // 
            this.bnt_show_SlideRecord_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_show_SlideRecord_go.Location = new System.Drawing.Point(158, 397);
            this.bnt_show_SlideRecord_go.Name = "bnt_show_SlideRecord_go";
            this.bnt_show_SlideRecord_go.Size = new System.Drawing.Size(56, 28);
            this.bnt_show_SlideRecord_go.TabIndex = 66;
            this.bnt_show_SlideRecord_go.Text = "GO";
            this.bnt_show_SlideRecord_go.UseVisualStyleBackColor = true;
            this.bnt_show_SlideRecord_go.Click += new System.EventHandler(this.bnt_show_SlideRecord_go_Click);
            // 
            // lbl_intake_SlideRecord_show_select
            // 
            this.lbl_intake_SlideRecord_show_select.AutoSize = true;
            this.lbl_intake_SlideRecord_show_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_SlideRecord_show_select.Location = new System.Drawing.Point(37, 71);
            this.lbl_intake_SlideRecord_show_select.Name = "lbl_intake_SlideRecord_show_select";
            this.lbl_intake_SlideRecord_show_select.Size = new System.Drawing.Size(138, 25);
            this.lbl_intake_SlideRecord_show_select.TabIndex = 65;
            this.lbl_intake_SlideRecord_show_select.Text = "Select Intake";
            // 
            // comboBox_intake_select_SlideRecord
            // 
            this.comboBox_intake_select_SlideRecord.FormattingEnabled = true;
            this.comboBox_intake_select_SlideRecord.Location = new System.Drawing.Point(39, 102);
            this.comboBox_intake_select_SlideRecord.Name = "comboBox_intake_select_SlideRecord";
            this.comboBox_intake_select_SlideRecord.Size = new System.Drawing.Size(174, 24);
            this.comboBox_intake_select_SlideRecord.TabIndex = 64;
            this.comboBox_intake_select_SlideRecord.SelectedIndexChanged += new System.EventHandler(this.comboBox_intake_select_SlideRecord_SelectedIndexChanged);
            // 
            // txt_show_SlideRecord_intake
            // 
            this.txt_show_SlideRecord_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_show_SlideRecord_intake.Location = new System.Drawing.Point(40, 224);
            this.txt_show_SlideRecord_intake.Name = "txt_show_SlideRecord_intake";
            this.txt_show_SlideRecord_intake.Size = new System.Drawing.Size(174, 30);
            this.txt_show_SlideRecord_intake.TabIndex = 63;
            // 
            // lbl_intake_show_SlideRecord
            // 
            this.lbl_intake_show_SlideRecord.AutoSize = true;
            this.lbl_intake_show_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_show_SlideRecord.Location = new System.Drawing.Point(37, 196);
            this.lbl_intake_show_SlideRecord.Name = "lbl_intake_show_SlideRecord";
            this.lbl_intake_show_SlideRecord.Size = new System.Drawing.Size(71, 25);
            this.lbl_intake_show_SlideRecord.TabIndex = 62;
            this.lbl_intake_show_SlideRecord.Text = "Intake";
            // 
            // dataGridView_SlideRecord_show_admin
            // 
            this.dataGridView_SlideRecord_show_admin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_SlideRecord_show_admin.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_SlideRecord_show_admin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_SlideRecord_show_admin.Location = new System.Drawing.Point(231, 63);
            this.dataGridView_SlideRecord_show_admin.Name = "dataGridView_SlideRecord_show_admin";
            this.dataGridView_SlideRecord_show_admin.RowHeadersVisible = false;
            this.dataGridView_SlideRecord_show_admin.RowHeadersWidth = 51;
            this.dataGridView_SlideRecord_show_admin.RowTemplate.Height = 24;
            this.dataGridView_SlideRecord_show_admin.Size = new System.Drawing.Size(743, 374);
            this.dataGridView_SlideRecord_show_admin.TabIndex = 61;
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(901, 447);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 60;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(40, 447);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 59;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // txt_show_SlideRecord_date
            // 
            this.txt_show_SlideRecord_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_show_SlideRecord_date.Location = new System.Drawing.Point(40, 358);
            this.txt_show_SlideRecord_date.Name = "txt_show_SlideRecord_date";
            this.txt_show_SlideRecord_date.Size = new System.Drawing.Size(174, 30);
            this.txt_show_SlideRecord_date.TabIndex = 70;
            // 
            // lbl_date_show_SlideRecord
            // 
            this.lbl_date_show_SlideRecord.AutoSize = true;
            this.lbl_date_show_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date_show_SlideRecord.Location = new System.Drawing.Point(37, 330);
            this.lbl_date_show_SlideRecord.Name = "lbl_date_show_SlideRecord";
            this.lbl_date_show_SlideRecord.Size = new System.Drawing.Size(138, 25);
            this.lbl_date_show_SlideRecord.TabIndex = 69;
            this.lbl_date_show_SlideRecord.Text = "Perform Date";
            // 
            // dateTimePicker_SlideRecord
            // 
            this.dateTimePicker_SlideRecord.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_SlideRecord.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker_SlideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_SlideRecord.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_SlideRecord.Location = new System.Drawing.Point(39, 141);
            this.dateTimePicker_SlideRecord.Name = "dateTimePicker_SlideRecord";
            this.dateTimePicker_SlideRecord.Size = new System.Drawing.Size(175, 27);
            this.dateTimePicker_SlideRecord.TabIndex = 75;
            this.dateTimePicker_SlideRecord.ValueChanged += new System.EventHandler(this.dateTimePicker_SlideRecord_ValueChanged);
            // 
            // lbl_top_show_slideRecord
            // 
            this.lbl_top_show_slideRecord.AutoSize = true;
            this.lbl_top_show_slideRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_show_slideRecord.Location = new System.Drawing.Point(364, 8);
            this.lbl_top_show_slideRecord.Name = "lbl_top_show_slideRecord";
            this.lbl_top_show_slideRecord.Size = new System.Drawing.Size(290, 29);
            this.lbl_top_show_slideRecord.TabIndex = 87;
            this.lbl_top_show_slideRecord.Text = "Slide And Class Record";
            // 
            // Form_admin_SlideRecord_show
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.lbl_top_show_slideRecord);
            this.Controls.Add(this.dateTimePicker_SlideRecord);
            this.Controls.Add(this.txt_show_SlideRecord_date);
            this.Controls.Add(this.lbl_date_show_SlideRecord);
            this.Controls.Add(this.txt_show_SlideRecord_sec);
            this.Controls.Add(this.lbl_sec_show_SlideRecord);
            this.Controls.Add(this.bnt_show_SlideRecord_go);
            this.Controls.Add(this.lbl_intake_SlideRecord_show_select);
            this.Controls.Add(this.comboBox_intake_select_SlideRecord);
            this.Controls.Add(this.txt_show_SlideRecord_intake);
            this.Controls.Add(this.lbl_intake_show_SlideRecord);
            this.Controls.Add(this.dataGridView_SlideRecord_show_admin);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.DoubleBuffered = true;
            this.Name = "Form_admin_SlideRecord_show";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_admin_SlideRecord_show_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_SlideRecord_show_admin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_show_SlideRecord_sec;
        private System.Windows.Forms.Label lbl_sec_show_SlideRecord;
        private System.Windows.Forms.Button bnt_show_SlideRecord_go;
        private System.Windows.Forms.Label lbl_intake_SlideRecord_show_select;
        private System.Windows.Forms.ComboBox comboBox_intake_select_SlideRecord;
        private System.Windows.Forms.TextBox txt_show_SlideRecord_intake;
        private System.Windows.Forms.Label lbl_intake_show_SlideRecord;
        private System.Windows.Forms.DataGridView dataGridView_SlideRecord_show_admin;
        private System.Windows.Forms.Button btn_back_fm12_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.TextBox txt_show_SlideRecord_date;
        private System.Windows.Forms.Label lbl_date_show_SlideRecord;
        private System.Windows.Forms.DateTimePicker dateTimePicker_SlideRecord;
        private System.Windows.Forms.Label lbl_top_show_slideRecord;
    }
}