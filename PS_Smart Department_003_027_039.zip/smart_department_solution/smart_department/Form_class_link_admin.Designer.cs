﻿
namespace smart_department
{
    partial class Form_class_link_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_class_link_admin));
            this.btn_back_fm5 = new System.Windows.Forms.Button();
            this.lbl_intake_classlink_select = new System.Windows.Forms.Label();
            this.comboBox_intake_select_classlink = new System.Windows.Forms.ComboBox();
            this.txt_insert_classlink_intake = new System.Windows.Forms.TextBox();
            this.lbl_intake_classlink = new System.Windows.Forms.Label();
            this.txt_insert_section_classlink = new System.Windows.Forms.TextBox();
            this.lbl_sec_classlink = new System.Windows.Forms.Label();
            this.btn_insert_classlink = new System.Windows.Forms.Button();
            this.lbl_course_id_classlink = new System.Windows.Forms.Label();
            this.txt_insert_course_id_classlink = new System.Windows.Forms.TextBox();
            this.txt_insert_link_classlink = new System.Windows.Forms.TextBox();
            this.lbl_link_classlink = new System.Windows.Forms.Label();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.txt_insert_classCode_classlink = new System.Windows.Forms.TextBox();
            this.lbl_classCode_classlink = new System.Windows.Forms.Label();
            this.lbl_top_insert_classlink = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_back_fm5
            // 
            this.btn_back_fm5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm5.Location = new System.Drawing.Point(903, 449);
            this.btn_back_fm5.Name = "btn_back_fm5";
            this.btn_back_fm5.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm5.TabIndex = 15;
            this.btn_back_fm5.Text = "BACK";
            this.btn_back_fm5.UseVisualStyleBackColor = false;
            this.btn_back_fm5.Click += new System.EventHandler(this.btn_back_fm5_Click);
            // 
            // lbl_intake_classlink_select
            // 
            this.lbl_intake_classlink_select.AutoSize = true;
            this.lbl_intake_classlink_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_classlink_select.Location = new System.Drawing.Point(626, 91);
            this.lbl_intake_classlink_select.Name = "lbl_intake_classlink_select";
            this.lbl_intake_classlink_select.Size = new System.Drawing.Size(73, 25);
            this.lbl_intake_classlink_select.TabIndex = 31;
            this.lbl_intake_classlink_select.Text = "Select";
            // 
            // comboBox_intake_select_classlink
            // 
            this.comboBox_intake_select_classlink.FormattingEnabled = true;
            this.comboBox_intake_select_classlink.Location = new System.Drawing.Point(626, 122);
            this.comboBox_intake_select_classlink.Name = "comboBox_intake_select_classlink";
            this.comboBox_intake_select_classlink.Size = new System.Drawing.Size(73, 24);
            this.comboBox_intake_select_classlink.TabIndex = 30;
            this.comboBox_intake_select_classlink.SelectedIndexChanged += new System.EventHandler(this.comboBox_intake_select_classlink_SelectedIndexChanged);
            // 
            // txt_insert_classlink_intake
            // 
            this.txt_insert_classlink_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_classlink_intake.Location = new System.Drawing.Point(297, 122);
            this.txt_insert_classlink_intake.Name = "txt_insert_classlink_intake";
            this.txt_insert_classlink_intake.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_classlink_intake.TabIndex = 29;
            // 
            // lbl_intake_classlink
            // 
            this.lbl_intake_classlink.AutoSize = true;
            this.lbl_intake_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_classlink.Location = new System.Drawing.Point(298, 94);
            this.lbl_intake_classlink.Name = "lbl_intake_classlink";
            this.lbl_intake_classlink.Size = new System.Drawing.Size(71, 25);
            this.lbl_intake_classlink.TabIndex = 28;
            this.lbl_intake_classlink.Text = "Intake";
            // 
            // txt_insert_section_classlink
            // 
            this.txt_insert_section_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_section_classlink.Location = new System.Drawing.Point(297, 191);
            this.txt_insert_section_classlink.Name = "txt_insert_section_classlink";
            this.txt_insert_section_classlink.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_section_classlink.TabIndex = 27;
            // 
            // lbl_sec_classlink
            // 
            this.lbl_sec_classlink.AutoSize = true;
            this.lbl_sec_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sec_classlink.Location = new System.Drawing.Point(297, 163);
            this.lbl_sec_classlink.Name = "lbl_sec_classlink";
            this.lbl_sec_classlink.Size = new System.Drawing.Size(85, 25);
            this.lbl_sec_classlink.TabIndex = 26;
            this.lbl_sec_classlink.Text = "Section";
            // 
            // btn_insert_classlink
            // 
            this.btn_insert_classlink.Location = new System.Drawing.Point(640, 399);
            this.btn_insert_classlink.Name = "btn_insert_classlink";
            this.btn_insert_classlink.Size = new System.Drawing.Size(59, 30);
            this.btn_insert_classlink.TabIndex = 25;
            this.btn_insert_classlink.Text = "GO";
            this.btn_insert_classlink.UseVisualStyleBackColor = true;
            this.btn_insert_classlink.Click += new System.EventHandler(this.btn_insert_classlink_Click);
            // 
            // lbl_course_id_classlink
            // 
            this.lbl_course_id_classlink.AutoSize = true;
            this.lbl_course_id_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course_id_classlink.Location = new System.Drawing.Point(297, 231);
            this.lbl_course_id_classlink.Name = "lbl_course_id_classlink";
            this.lbl_course_id_classlink.Size = new System.Drawing.Size(109, 25);
            this.lbl_course_id_classlink.TabIndex = 23;
            this.lbl_course_id_classlink.Text = "Course ID";
            // 
            // txt_insert_course_id_classlink
            // 
            this.txt_insert_course_id_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_course_id_classlink.Location = new System.Drawing.Point(297, 259);
            this.txt_insert_course_id_classlink.Name = "txt_insert_course_id_classlink";
            this.txt_insert_course_id_classlink.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_course_id_classlink.TabIndex = 33;
            // 
            // txt_insert_link_classlink
            // 
            this.txt_insert_link_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_link_classlink.Location = new System.Drawing.Point(298, 395);
            this.txt_insert_link_classlink.Name = "txt_insert_link_classlink";
            this.txt_insert_link_classlink.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_link_classlink.TabIndex = 35;
            // 
            // lbl_link_classlink
            // 
            this.lbl_link_classlink.AutoSize = true;
            this.lbl_link_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_link_classlink.Location = new System.Drawing.Point(298, 367);
            this.lbl_link_classlink.Name = "lbl_link_classlink";
            this.lbl_link_classlink.Size = new System.Drawing.Size(113, 25);
            this.lbl_link_classlink.TabIndex = 34;
            this.lbl_link_classlink.Text = "Class Link";
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(38, 452);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 36;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // txt_insert_classCode_classlink
            // 
            this.txt_insert_classCode_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_classCode_classlink.Location = new System.Drawing.Point(298, 327);
            this.txt_insert_classCode_classlink.Name = "txt_insert_classCode_classlink";
            this.txt_insert_classCode_classlink.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_classCode_classlink.TabIndex = 38;
            // 
            // lbl_classCode_classlink
            // 
            this.lbl_classCode_classlink.AutoSize = true;
            this.lbl_classCode_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_classCode_classlink.Location = new System.Drawing.Point(298, 299);
            this.lbl_classCode_classlink.Name = "lbl_classCode_classlink";
            this.lbl_classCode_classlink.Size = new System.Drawing.Size(248, 25);
            this.lbl_classCode_classlink.TabIndex = 37;
            this.lbl_classCode_classlink.Text = "Google Classroom Code";
            // 
            // lbl_top_insert_classlink
            // 
            this.lbl_top_insert_classlink.AutoSize = true;
            this.lbl_top_insert_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_insert_classlink.Location = new System.Drawing.Point(407, 9);
            this.lbl_top_insert_classlink.Name = "lbl_top_insert_classlink";
            this.lbl_top_insert_classlink.Size = new System.Drawing.Size(205, 29);
            this.lbl_top_insert_classlink.TabIndex = 90;
            this.lbl_top_insert_classlink.Text = "Insert Class Link";
            // 
            // Form_class_link_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.lbl_top_insert_classlink);
            this.Controls.Add(this.txt_insert_classCode_classlink);
            this.Controls.Add(this.lbl_classCode_classlink);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.txt_insert_link_classlink);
            this.Controls.Add(this.lbl_link_classlink);
            this.Controls.Add(this.txt_insert_course_id_classlink);
            this.Controls.Add(this.lbl_intake_classlink_select);
            this.Controls.Add(this.comboBox_intake_select_classlink);
            this.Controls.Add(this.txt_insert_classlink_intake);
            this.Controls.Add(this.lbl_intake_classlink);
            this.Controls.Add(this.txt_insert_section_classlink);
            this.Controls.Add(this.lbl_sec_classlink);
            this.Controls.Add(this.btn_insert_classlink);
            this.Controls.Add(this.lbl_course_id_classlink);
            this.Controls.Add(this.btn_back_fm5);
            this.DoubleBuffered = true;
            this.Name = "Form_class_link_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_class_link_admin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_back_fm5;
        private System.Windows.Forms.Label lbl_intake_classlink_select;
        private System.Windows.Forms.ComboBox comboBox_intake_select_classlink;
        private System.Windows.Forms.TextBox txt_insert_classlink_intake;
        private System.Windows.Forms.Label lbl_intake_classlink;
        private System.Windows.Forms.TextBox txt_insert_section_classlink;
        private System.Windows.Forms.Label lbl_sec_classlink;
        private System.Windows.Forms.Button btn_insert_classlink;
        private System.Windows.Forms.Label lbl_course_id_classlink;
        private System.Windows.Forms.TextBox txt_insert_course_id_classlink;
        private System.Windows.Forms.TextBox txt_insert_link_classlink;
        private System.Windows.Forms.Label lbl_link_classlink;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.TextBox txt_insert_classCode_classlink;
        private System.Windows.Forms.Label lbl_classCode_classlink;
        private System.Windows.Forms.Label lbl_top_insert_classlink;
    }
}