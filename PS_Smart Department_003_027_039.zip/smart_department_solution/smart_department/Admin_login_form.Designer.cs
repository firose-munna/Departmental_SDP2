﻿
namespace smart_department
{
    partial class Admin_login_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_login_form));
            this.pictureBox_Admin_login = new System.Windows.Forms.PictureBox();
            this.txt_admin_code = new System.Windows.Forms.TextBox();
            this.lbl_admin_login = new System.Windows.Forms.Label();
            this.lbl_Admin_kye = new System.Windows.Forms.Label();
            this.txt_Admin_Kye = new System.Windows.Forms.TextBox();
            this.btn_Admin_login = new System.Windows.Forms.Button();
            this.btn_back_fm2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Admin_login)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_Admin_login
            // 
            this.pictureBox_Admin_login.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_Admin_login.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox_Admin_login.BackgroundImage")));
            this.pictureBox_Admin_login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_Admin_login.Location = new System.Drawing.Point(223, 193);
            this.pictureBox_Admin_login.Name = "pictureBox_Admin_login";
            this.pictureBox_Admin_login.Size = new System.Drawing.Size(148, 152);
            this.pictureBox_Admin_login.TabIndex = 0;
            this.pictureBox_Admin_login.TabStop = false;
            // 
            // txt_admin_code
            // 
            this.txt_admin_code.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_admin_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_code.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_admin_code.Location = new System.Drawing.Point(398, 221);
            this.txt_admin_code.Name = "txt_admin_code";
            this.txt_admin_code.Size = new System.Drawing.Size(216, 30);
            this.txt_admin_code.TabIndex = 1;
            this.txt_admin_code.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_admin_login
            // 
            this.lbl_admin_login.AutoSize = true;
            this.lbl_admin_login.BackColor = System.Drawing.Color.Transparent;
            this.lbl_admin_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_login.Location = new System.Drawing.Point(398, 193);
            this.lbl_admin_login.Name = "lbl_admin_login";
            this.lbl_admin_login.Size = new System.Drawing.Size(131, 25);
            this.lbl_admin_login.TabIndex = 2;
            this.lbl_admin_login.Text = "Admin Code";
            // 
            // lbl_Admin_kye
            // 
            this.lbl_Admin_kye.AutoSize = true;
            this.lbl_Admin_kye.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Admin_kye.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Admin_kye.Location = new System.Drawing.Point(398, 275);
            this.lbl_Admin_kye.Name = "lbl_Admin_kye";
            this.lbl_Admin_kye.Size = new System.Drawing.Size(117, 25);
            this.lbl_Admin_kye.TabIndex = 4;
            this.lbl_Admin_kye.Text = "Admin Key";
            // 
            // txt_Admin_Kye
            // 
            this.txt_Admin_Kye.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_Admin_Kye.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Admin_Kye.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_Admin_Kye.Location = new System.Drawing.Point(398, 303);
            this.txt_Admin_Kye.Name = "txt_Admin_Kye";
            this.txt_Admin_Kye.Size = new System.Drawing.Size(216, 30);
            this.txt_Admin_Kye.TabIndex = 3;
            this.txt_Admin_Kye.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_Admin_Kye.UseSystemPasswordChar = true;
            // 
            // btn_Admin_login
            // 
            this.btn_Admin_login.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_Admin_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Admin_login.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Admin_login.Location = new System.Drawing.Point(655, 303);
            this.btn_Admin_login.Name = "btn_Admin_login";
            this.btn_Admin_login.Size = new System.Drawing.Size(95, 34);
            this.btn_Admin_login.TabIndex = 5;
            this.btn_Admin_login.Text = "LOG IN";
            this.btn_Admin_login.UseVisualStyleBackColor = false;
            this.btn_Admin_login.Click += new System.EventHandler(this.btn_Admin_login_Click);
            // 
            // btn_back_fm2
            // 
            this.btn_back_fm2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm2.Location = new System.Drawing.Point(901, 448);
            this.btn_back_fm2.Name = "btn_back_fm2";
            this.btn_back_fm2.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm2.TabIndex = 128;
            this.btn_back_fm2.Text = "BACK";
            this.btn_back_fm2.UseVisualStyleBackColor = false;
            this.btn_back_fm2.Click += new System.EventHandler(this.btn_back_fm2_Click);
            // 
            // Admin_login_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.btn_back_fm2);
            this.Controls.Add(this.btn_Admin_login);
            this.Controls.Add(this.lbl_Admin_kye);
            this.Controls.Add(this.txt_Admin_Kye);
            this.Controls.Add(this.lbl_admin_login);
            this.Controls.Add(this.txt_admin_code);
            this.Controls.Add(this.pictureBox_Admin_login);
            this.DoubleBuffered = true;
            this.Name = "Admin_login_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Admin_login_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Admin_login)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_Admin_login;
        private System.Windows.Forms.TextBox txt_admin_code;
        private System.Windows.Forms.Label lbl_admin_login;
        private System.Windows.Forms.Label lbl_Admin_kye;
        private System.Windows.Forms.TextBox txt_Admin_Kye;
        private System.Windows.Forms.Button btn_Admin_login;
        private System.Windows.Forms.Button btn_back_fm2;
    }
}