﻿
namespace smart_department
{
    partial class Form_RBook_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_RBook_admin));
            this.btn_back_fm5 = new System.Windows.Forms.Button();
            this.txt_insert_Bname_RBook = new System.Windows.Forms.TextBox();
            this.lbl_Bname_RBook = new System.Windows.Forms.Label();
            this.txt_insert_course_id_RBook = new System.Windows.Forms.TextBox();
            this.lbl_intake_RBook_select = new System.Windows.Forms.Label();
            this.txt_insert_RBook_intake = new System.Windows.Forms.TextBox();
            this.lbl_intake_RBook = new System.Windows.Forms.Label();
            this.txt_insert_section_RBook = new System.Windows.Forms.TextBox();
            this.lbl_sec_RBook = new System.Windows.Forms.Label();
            this.btn_insert_RBook = new System.Windows.Forms.Button();
            this.lbl_course_id_RBook = new System.Windows.Forms.Label();
            this.txt_insert_Aname_RBook = new System.Windows.Forms.TextBox();
            this.lbl_Aname_RBook = new System.Windows.Forms.Label();
            this.txt_insert_Blink_RBook = new System.Windows.Forms.TextBox();
            this.lbl_Blink_RBook = new System.Windows.Forms.Label();
            this.txt_insert_editon_RBook = new System.Windows.Forms.TextBox();
            this.lbl_edition_RBook = new System.Windows.Forms.Label();
            this.comboBox_intake_select_RBook = new System.Windows.Forms.ComboBox();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.lbl_top_insert_RBook = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_back_fm5
            // 
            this.btn_back_fm5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm5.Location = new System.Drawing.Point(903, 448);
            this.btn_back_fm5.Name = "btn_back_fm5";
            this.btn_back_fm5.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm5.TabIndex = 16;
            this.btn_back_fm5.Text = "BACK";
            this.btn_back_fm5.UseVisualStyleBackColor = false;
            this.btn_back_fm5.Click += new System.EventHandler(this.btn_back_fm5_Click);
            // 
            // txt_insert_Bname_RBook
            // 
            this.txt_insert_Bname_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_Bname_RBook.Location = new System.Drawing.Point(582, 154);
            this.txt_insert_Bname_RBook.Name = "txt_insert_Bname_RBook";
            this.txt_insert_Bname_RBook.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_Bname_RBook.TabIndex = 47;
            // 
            // lbl_Bname_RBook
            // 
            this.lbl_Bname_RBook.AutoSize = true;
            this.lbl_Bname_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bname_RBook.Location = new System.Drawing.Point(582, 126);
            this.lbl_Bname_RBook.Name = "lbl_Bname_RBook";
            this.lbl_Bname_RBook.Size = new System.Drawing.Size(123, 25);
            this.lbl_Bname_RBook.TabIndex = 46;
            this.lbl_Bname_RBook.Text = "Book Name";
            // 
            // txt_insert_course_id_RBook
            // 
            this.txt_insert_course_id_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_course_id_RBook.Location = new System.Drawing.Point(86, 302);
            this.txt_insert_course_id_RBook.Name = "txt_insert_course_id_RBook";
            this.txt_insert_course_id_RBook.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_course_id_RBook.TabIndex = 45;
            // 
            // lbl_intake_RBook_select
            // 
            this.lbl_intake_RBook_select.AutoSize = true;
            this.lbl_intake_RBook_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_RBook_select.Location = new System.Drawing.Point(415, 123);
            this.lbl_intake_RBook_select.Name = "lbl_intake_RBook_select";
            this.lbl_intake_RBook_select.Size = new System.Drawing.Size(73, 25);
            this.lbl_intake_RBook_select.TabIndex = 43;
            this.lbl_intake_RBook_select.Text = "Select";
            // 
            // txt_insert_RBook_intake
            // 
            this.txt_insert_RBook_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_RBook_intake.Location = new System.Drawing.Point(86, 154);
            this.txt_insert_RBook_intake.Name = "txt_insert_RBook_intake";
            this.txt_insert_RBook_intake.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_RBook_intake.TabIndex = 41;
            // 
            // lbl_intake_RBook
            // 
            this.lbl_intake_RBook.AutoSize = true;
            this.lbl_intake_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intake_RBook.Location = new System.Drawing.Point(87, 126);
            this.lbl_intake_RBook.Name = "lbl_intake_RBook";
            this.lbl_intake_RBook.Size = new System.Drawing.Size(71, 25);
            this.lbl_intake_RBook.TabIndex = 40;
            this.lbl_intake_RBook.Text = "Intake";
            // 
            // txt_insert_section_RBook
            // 
            this.txt_insert_section_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_section_RBook.Location = new System.Drawing.Point(86, 229);
            this.txt_insert_section_RBook.Name = "txt_insert_section_RBook";
            this.txt_insert_section_RBook.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_section_RBook.TabIndex = 39;
            // 
            // lbl_sec_RBook
            // 
            this.lbl_sec_RBook.AutoSize = true;
            this.lbl_sec_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sec_RBook.Location = new System.Drawing.Point(86, 201);
            this.lbl_sec_RBook.Name = "lbl_sec_RBook";
            this.lbl_sec_RBook.Size = new System.Drawing.Size(85, 25);
            this.lbl_sec_RBook.TabIndex = 38;
            this.lbl_sec_RBook.Text = "Section";
            // 
            // btn_insert_RBook
            // 
            this.btn_insert_RBook.Location = new System.Drawing.Point(916, 379);
            this.btn_insert_RBook.Name = "btn_insert_RBook";
            this.btn_insert_RBook.Size = new System.Drawing.Size(59, 30);
            this.btn_insert_RBook.TabIndex = 37;
            this.btn_insert_RBook.Text = "GO";
            this.btn_insert_RBook.UseVisualStyleBackColor = true;
            this.btn_insert_RBook.Click += new System.EventHandler(this.btn_insert_RBook_Click);
            // 
            // lbl_course_id_RBook
            // 
            this.lbl_course_id_RBook.AutoSize = true;
            this.lbl_course_id_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_course_id_RBook.Location = new System.Drawing.Point(86, 274);
            this.lbl_course_id_RBook.Name = "lbl_course_id_RBook";
            this.lbl_course_id_RBook.Size = new System.Drawing.Size(109, 25);
            this.lbl_course_id_RBook.TabIndex = 36;
            this.lbl_course_id_RBook.Text = "Course ID";
            // 
            // txt_insert_Aname_RBook
            // 
            this.txt_insert_Aname_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_Aname_RBook.Location = new System.Drawing.Point(582, 229);
            this.txt_insert_Aname_RBook.Name = "txt_insert_Aname_RBook";
            this.txt_insert_Aname_RBook.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_Aname_RBook.TabIndex = 49;
            // 
            // lbl_Aname_RBook
            // 
            this.lbl_Aname_RBook.AutoSize = true;
            this.lbl_Aname_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aname_RBook.Location = new System.Drawing.Point(582, 201);
            this.lbl_Aname_RBook.Name = "lbl_Aname_RBook";
            this.lbl_Aname_RBook.Size = new System.Drawing.Size(138, 25);
            this.lbl_Aname_RBook.TabIndex = 48;
            this.lbl_Aname_RBook.Text = "Author Name";
            // 
            // txt_insert_Blink_RBook
            // 
            this.txt_insert_Blink_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_Blink_RBook.Location = new System.Drawing.Point(582, 379);
            this.txt_insert_Blink_RBook.Name = "txt_insert_Blink_RBook";
            this.txt_insert_Blink_RBook.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_Blink_RBook.TabIndex = 51;
            // 
            // lbl_Blink_RBook
            // 
            this.lbl_Blink_RBook.AutoSize = true;
            this.lbl_Blink_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Blink_RBook.Location = new System.Drawing.Point(582, 351);
            this.lbl_Blink_RBook.Name = "lbl_Blink_RBook";
            this.lbl_Blink_RBook.Size = new System.Drawing.Size(107, 25);
            this.lbl_Blink_RBook.TabIndex = 50;
            this.lbl_Blink_RBook.Text = "Book Link";
            // 
            // txt_insert_editon_RBook
            // 
            this.txt_insert_editon_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_insert_editon_RBook.Location = new System.Drawing.Point(582, 302);
            this.txt_insert_editon_RBook.Name = "txt_insert_editon_RBook";
            this.txt_insert_editon_RBook.Size = new System.Drawing.Size(294, 30);
            this.txt_insert_editon_RBook.TabIndex = 53;
            // 
            // lbl_edition_RBook
            // 
            this.lbl_edition_RBook.AutoSize = true;
            this.lbl_edition_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_edition_RBook.Location = new System.Drawing.Point(582, 274);
            this.lbl_edition_RBook.Name = "lbl_edition_RBook";
            this.lbl_edition_RBook.Size = new System.Drawing.Size(78, 25);
            this.lbl_edition_RBook.TabIndex = 52;
            this.lbl_edition_RBook.Text = "Edition";
            // 
            // comboBox_intake_select_RBook
            // 
            this.comboBox_intake_select_RBook.FormattingEnabled = true;
            this.comboBox_intake_select_RBook.Location = new System.Drawing.Point(413, 157);
            this.comboBox_intake_select_RBook.Name = "comboBox_intake_select_RBook";
            this.comboBox_intake_select_RBook.Size = new System.Drawing.Size(73, 24);
            this.comboBox_intake_select_RBook.TabIndex = 54;
            this.comboBox_intake_select_RBook.SelectedIndexChanged += new System.EventHandler(this.comboBox_intake_select_RBook_SelectedIndexChanged);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(37, 449);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 55;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // lbl_top_insert_RBook
            // 
            this.lbl_top_insert_RBook.AutoSize = true;
            this.lbl_top_insert_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_insert_RBook.Location = new System.Drawing.Point(393, 9);
            this.lbl_top_insert_RBook.Name = "lbl_top_insert_RBook";
            this.lbl_top_insert_RBook.Size = new System.Drawing.Size(273, 29);
            this.lbl_top_insert_RBook.TabIndex = 92;
            this.lbl_top_insert_RBook.Text = "Insert Reference Book";
            // 
            // Form_RBook_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.lbl_top_insert_RBook);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.comboBox_intake_select_RBook);
            this.Controls.Add(this.txt_insert_editon_RBook);
            this.Controls.Add(this.lbl_edition_RBook);
            this.Controls.Add(this.txt_insert_Blink_RBook);
            this.Controls.Add(this.lbl_Blink_RBook);
            this.Controls.Add(this.txt_insert_Aname_RBook);
            this.Controls.Add(this.lbl_Aname_RBook);
            this.Controls.Add(this.txt_insert_Bname_RBook);
            this.Controls.Add(this.lbl_Bname_RBook);
            this.Controls.Add(this.txt_insert_course_id_RBook);
            this.Controls.Add(this.lbl_intake_RBook_select);
            this.Controls.Add(this.txt_insert_RBook_intake);
            this.Controls.Add(this.lbl_intake_RBook);
            this.Controls.Add(this.txt_insert_section_RBook);
            this.Controls.Add(this.lbl_sec_RBook);
            this.Controls.Add(this.btn_insert_RBook);
            this.Controls.Add(this.lbl_course_id_RBook);
            this.Controls.Add(this.btn_back_fm5);
            this.DoubleBuffered = true;
            this.Name = "Form_RBook_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_RBook_admin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_back_fm5;
        private System.Windows.Forms.TextBox txt_insert_Bname_RBook;
        private System.Windows.Forms.Label lbl_Bname_RBook;
        private System.Windows.Forms.TextBox txt_insert_course_id_RBook;
        private System.Windows.Forms.Label lbl_intake_RBook_select;
        private System.Windows.Forms.TextBox txt_insert_RBook_intake;
        private System.Windows.Forms.Label lbl_intake_RBook;
        private System.Windows.Forms.TextBox txt_insert_section_RBook;
        private System.Windows.Forms.Label lbl_sec_RBook;
        private System.Windows.Forms.Button btn_insert_RBook;
        private System.Windows.Forms.Label lbl_course_id_RBook;
        private System.Windows.Forms.TextBox txt_insert_Aname_RBook;
        private System.Windows.Forms.Label lbl_Aname_RBook;
        private System.Windows.Forms.TextBox txt_insert_Blink_RBook;
        private System.Windows.Forms.Label lbl_Blink_RBook;
        private System.Windows.Forms.TextBox txt_insert_editon_RBook;
        private System.Windows.Forms.Label lbl_edition_RBook;
        private System.Windows.Forms.ComboBox comboBox_intake_select_RBook;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Label lbl_top_insert_RBook;
    }
}