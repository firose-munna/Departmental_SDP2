﻿
namespace smart_department
{
    partial class Form_admin_update_notice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_admin_update_notice));
            this.dataGridView_admin_update_notice = new System.Windows.Forms.DataGridView();
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.btn_admin_update_notice_deleteGo = new System.Windows.Forms.Button();
            this.lbl_top_admin_update_notice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_notice)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_admin_update_notice
            // 
            this.dataGridView_admin_update_notice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_admin_update_notice.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_admin_update_notice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_admin_update_notice.Location = new System.Drawing.Point(29, 51);
            this.dataGridView_admin_update_notice.Name = "dataGridView_admin_update_notice";
            this.dataGridView_admin_update_notice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView_admin_update_notice.RowHeadersVisible = false;
            this.dataGridView_admin_update_notice.RowHeadersWidth = 51;
            this.dataGridView_admin_update_notice.RowTemplate.Height = 24;
            this.dataGridView_admin_update_notice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_admin_update_notice.Size = new System.Drawing.Size(956, 329);
            this.dataGridView_admin_update_notice.TabIndex = 163;
            this.dataGridView_admin_update_notice.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_admin_update_notice_CellContentClick);
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(909, 454);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 162;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(31, 454);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 161;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // btn_admin_update_notice_deleteGo
            // 
            this.btn_admin_update_notice_deleteGo.BackColor = System.Drawing.Color.Red;
            this.btn_admin_update_notice_deleteGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_notice_deleteGo.Location = new System.Drawing.Point(857, 386);
            this.btn_admin_update_notice_deleteGo.Name = "btn_admin_update_notice_deleteGo";
            this.btn_admin_update_notice_deleteGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_notice_deleteGo.TabIndex = 160;
            this.btn_admin_update_notice_deleteGo.Text = "DELETE";
            this.btn_admin_update_notice_deleteGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_notice_deleteGo.Click += new System.EventHandler(this.btn_admin_update_notice_deleteGo_Click);
            // 
            // lbl_top_admin_update_notice
            // 
            this.lbl_top_admin_update_notice.AutoSize = true;
            this.lbl_top_admin_update_notice.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_admin_update_notice.Location = new System.Drawing.Point(440, 10);
            this.lbl_top_admin_update_notice.Name = "lbl_top_admin_update_notice";
            this.lbl_top_admin_update_notice.Size = new System.Drawing.Size(103, 29);
            this.lbl_top_admin_update_notice.TabIndex = 159;
            this.lbl_top_admin_update_notice.Text = "Routine";
            // 
            // Form_admin_update_notice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.dataGridView_admin_update_notice);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.btn_admin_update_notice_deleteGo);
            this.Controls.Add(this.lbl_top_admin_update_notice);
            this.DoubleBuffered = true;
            this.Name = "Form_admin_update_notice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_admin_update_notice_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_notice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_admin_update_notice;
        private System.Windows.Forms.Button btn_back_fm12_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Button btn_admin_update_notice_deleteGo;
        private System.Windows.Forms.Label lbl_top_admin_update_notice;
    }
}