﻿
namespace smart_department
{
    partial class Form_std_show_classlink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_std_show_classlink));
            this.lbl_top_std_show_classlink = new System.Windows.Forms.Label();
            this.txt_std_show_classlink_sec = new System.Windows.Forms.TextBox();
            this.lbl_std_show_classlink_sec = new System.Windows.Forms.Label();
            this.bnt_std_show_classlink_go = new System.Windows.Forms.Button();
            this.lbl_std_show_classlink_intake_select = new System.Windows.Forms.Label();
            this.comboBox_std_show_classlink_intake_select = new System.Windows.Forms.ComboBox();
            this.txt_std_show_classlink_intake = new System.Windows.Forms.TextBox();
            this.lbl_std_show_classlink_intake = new System.Windows.Forms.Label();
            this.dataGridView_std_show_classlink = new System.Windows.Forms.DataGridView();
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.linkLbl_golink = new System.Windows.Forms.LinkLabel();
            this.txt_std_show_classlink_selectlink = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_std_show_classlink)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_top_std_show_classlink
            // 
            this.lbl_top_std_show_classlink.AutoSize = true;
            this.lbl_top_std_show_classlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_std_show_classlink.Location = new System.Drawing.Point(432, 9);
            this.lbl_top_std_show_classlink.Name = "lbl_top_std_show_classlink";
            this.lbl_top_std_show_classlink.Size = new System.Drawing.Size(133, 29);
            this.lbl_top_std_show_classlink.TabIndex = 107;
            this.lbl_top_std_show_classlink.Text = "Class Link";
            // 
            // txt_std_show_classlink_sec
            // 
            this.txt_std_show_classlink_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_std_show_classlink_sec.Location = new System.Drawing.Point(40, 303);
            this.txt_std_show_classlink_sec.Name = "txt_std_show_classlink_sec";
            this.txt_std_show_classlink_sec.Size = new System.Drawing.Size(174, 30);
            this.txt_std_show_classlink_sec.TabIndex = 106;
            // 
            // lbl_std_show_classlink_sec
            // 
            this.lbl_std_show_classlink_sec.AutoSize = true;
            this.lbl_std_show_classlink_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_std_show_classlink_sec.Location = new System.Drawing.Point(37, 275);
            this.lbl_std_show_classlink_sec.Name = "lbl_std_show_classlink_sec";
            this.lbl_std_show_classlink_sec.Size = new System.Drawing.Size(85, 25);
            this.lbl_std_show_classlink_sec.TabIndex = 105;
            this.lbl_std_show_classlink_sec.Text = "Section";
            // 
            // bnt_std_show_classlink_go
            // 
            this.bnt_std_show_classlink_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_std_show_classlink_go.Location = new System.Drawing.Point(158, 339);
            this.bnt_std_show_classlink_go.Name = "bnt_std_show_classlink_go";
            this.bnt_std_show_classlink_go.Size = new System.Drawing.Size(56, 28);
            this.bnt_std_show_classlink_go.TabIndex = 104;
            this.bnt_std_show_classlink_go.Text = "GO";
            this.bnt_std_show_classlink_go.UseVisualStyleBackColor = true;
            this.bnt_std_show_classlink_go.Click += new System.EventHandler(this.bnt_std_show_classlink_go_Click);
            // 
            // lbl_std_show_classlink_intake_select
            // 
            this.lbl_std_show_classlink_intake_select.AutoSize = true;
            this.lbl_std_show_classlink_intake_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_std_show_classlink_intake_select.Location = new System.Drawing.Point(37, 144);
            this.lbl_std_show_classlink_intake_select.Name = "lbl_std_show_classlink_intake_select";
            this.lbl_std_show_classlink_intake_select.Size = new System.Drawing.Size(138, 25);
            this.lbl_std_show_classlink_intake_select.TabIndex = 103;
            this.lbl_std_show_classlink_intake_select.Text = "Select Intake";
            // 
            // comboBox_std_show_classlink_intake_select
            // 
            this.comboBox_std_show_classlink_intake_select.FormattingEnabled = true;
            this.comboBox_std_show_classlink_intake_select.Location = new System.Drawing.Point(39, 175);
            this.comboBox_std_show_classlink_intake_select.Name = "comboBox_std_show_classlink_intake_select";
            this.comboBox_std_show_classlink_intake_select.Size = new System.Drawing.Size(174, 24);
            this.comboBox_std_show_classlink_intake_select.TabIndex = 102;
            this.comboBox_std_show_classlink_intake_select.SelectedIndexChanged += new System.EventHandler(this.comboBox_std_show_classlink_intake_select_SelectedIndexChanged);
            // 
            // txt_std_show_classlink_intake
            // 
            this.txt_std_show_classlink_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_std_show_classlink_intake.Location = new System.Drawing.Point(40, 237);
            this.txt_std_show_classlink_intake.Name = "txt_std_show_classlink_intake";
            this.txt_std_show_classlink_intake.Size = new System.Drawing.Size(174, 30);
            this.txt_std_show_classlink_intake.TabIndex = 101;
            // 
            // lbl_std_show_classlink_intake
            // 
            this.lbl_std_show_classlink_intake.AutoSize = true;
            this.lbl_std_show_classlink_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_std_show_classlink_intake.Location = new System.Drawing.Point(37, 209);
            this.lbl_std_show_classlink_intake.Name = "lbl_std_show_classlink_intake";
            this.lbl_std_show_classlink_intake.Size = new System.Drawing.Size(71, 25);
            this.lbl_std_show_classlink_intake.TabIndex = 100;
            this.lbl_std_show_classlink_intake.Text = "Intake";
            // 
            // dataGridView_std_show_classlink
            // 
            this.dataGridView_std_show_classlink.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_std_show_classlink.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_std_show_classlink.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_std_show_classlink.Location = new System.Drawing.Point(231, 63);
            this.dataGridView_std_show_classlink.Name = "dataGridView_std_show_classlink";
            this.dataGridView_std_show_classlink.RowHeadersVisible = false;
            this.dataGridView_std_show_classlink.RowHeadersWidth = 51;
            this.dataGridView_std_show_classlink.RowTemplate.Height = 24;
            this.dataGridView_std_show_classlink.Size = new System.Drawing.Size(743, 374);
            this.dataGridView_std_show_classlink.TabIndex = 99;
            this.dataGridView_std_show_classlink.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_std_show_classlink_CellContentClick);
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(901, 444);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 98;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(40, 447);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 97;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // linkLbl_golink
            // 
            this.linkLbl_golink.AutoSize = true;
            this.linkLbl_golink.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_golink.Location = new System.Drawing.Point(811, 451);
            this.linkLbl_golink.Name = "linkLbl_golink";
            this.linkLbl_golink.Size = new System.Drawing.Size(84, 20);
            this.linkLbl_golink.TabIndex = 109;
            this.linkLbl_golink.TabStop = true;
            this.linkLbl_golink.Text = "GO LINK";
            this.linkLbl_golink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_golink_LinkClicked);
            // 
            // txt_std_show_classlink_selectlink
            // 
            this.txt_std_show_classlink_selectlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_std_show_classlink_selectlink.Location = new System.Drawing.Point(231, 450);
            this.txt_std_show_classlink_selectlink.Name = "txt_std_show_classlink_selectlink";
            this.txt_std_show_classlink_selectlink.Size = new System.Drawing.Size(574, 22);
            this.txt_std_show_classlink_selectlink.TabIndex = 110;
            // 
            // Form_std_show_classlink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.txt_std_show_classlink_selectlink);
            this.Controls.Add(this.linkLbl_golink);
            this.Controls.Add(this.lbl_top_std_show_classlink);
            this.Controls.Add(this.txt_std_show_classlink_sec);
            this.Controls.Add(this.lbl_std_show_classlink_sec);
            this.Controls.Add(this.bnt_std_show_classlink_go);
            this.Controls.Add(this.lbl_std_show_classlink_intake_select);
            this.Controls.Add(this.comboBox_std_show_classlink_intake_select);
            this.Controls.Add(this.txt_std_show_classlink_intake);
            this.Controls.Add(this.lbl_std_show_classlink_intake);
            this.Controls.Add(this.dataGridView_std_show_classlink);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.DoubleBuffered = true;
            this.Name = "Form_std_show_classlink";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_std_show_classlink_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_std_show_classlink)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_top_std_show_classlink;
        private System.Windows.Forms.TextBox txt_std_show_classlink_sec;
        private System.Windows.Forms.Label lbl_std_show_classlink_sec;
        private System.Windows.Forms.Button bnt_std_show_classlink_go;
        private System.Windows.Forms.Label lbl_std_show_classlink_intake_select;
        private System.Windows.Forms.ComboBox comboBox_std_show_classlink_intake_select;
        private System.Windows.Forms.TextBox txt_std_show_classlink_intake;
        private System.Windows.Forms.Label lbl_std_show_classlink_intake;
        private System.Windows.Forms.DataGridView dataGridView_std_show_classlink;
        private System.Windows.Forms.Button btn_back_fm12_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.LinkLabel linkLbl_golink;
        private System.Windows.Forms.TextBox txt_std_show_classlink_selectlink;
    }
}