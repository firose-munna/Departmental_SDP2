﻿
namespace smart_department
{
    partial class Form_admin_update_basic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_admin_update_basic));
            this.dataGridView_admin_update_basic = new System.Windows.Forms.DataGridView();
            this.txt_admin_update_basic_course_id = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_course_id = new System.Windows.Forms.Label();
            this.bnt_admin_update_basic_go = new System.Windows.Forms.Button();
            this.lbl_admin_update_select_intake = new System.Windows.Forms.Label();
            this.comboBox_admin_update_basic_intake_select = new System.Windows.Forms.ComboBox();
            this.txt_admin_update_basic_intake = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_intake = new System.Windows.Forms.Label();
            this.lbl_top_admin_update_basic = new System.Windows.Forms.Label();
            this.txt_admin_update_basic_course_name = new System.Windows.Forms.TextBox();
            this.lbl_admin_update_course_name = new System.Windows.Forms.Label();
            this.btn_admin_update_basic_updateGo = new System.Windows.Forms.Button();
            this.btn_admin_update_basic_deleteGo = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.btn_back_fm12_show = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_basic)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_admin_update_basic
            // 
            this.dataGridView_admin_update_basic.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_admin_update_basic.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_admin_update_basic.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_admin_update_basic.Location = new System.Drawing.Point(29, 54);
            this.dataGridView_admin_update_basic.Name = "dataGridView_admin_update_basic";
            this.dataGridView_admin_update_basic.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView_admin_update_basic.RowHeadersVisible = false;
            this.dataGridView_admin_update_basic.RowHeadersWidth = 51;
            this.dataGridView_admin_update_basic.RowTemplate.Height = 24;
            this.dataGridView_admin_update_basic.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_admin_update_basic.Size = new System.Drawing.Size(956, 219);
            this.dataGridView_admin_update_basic.TabIndex = 0;
            this.dataGridView_admin_update_basic.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_admin_update_basic_CellContentClick);
            // 
            // txt_admin_update_basic_course_id
            // 
            this.txt_admin_update_basic_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_basic_course_id.Location = new System.Drawing.Point(362, 382);
            this.txt_admin_update_basic_course_id.Name = "txt_admin_update_basic_course_id";
            this.txt_admin_update_basic_course_id.Size = new System.Drawing.Size(333, 30);
            this.txt_admin_update_basic_course_id.TabIndex = 113;
            // 
            // lbl_admin_update_course_id
            // 
            this.lbl_admin_update_course_id.AutoSize = true;
            this.lbl_admin_update_course_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_course_id.Location = new System.Drawing.Point(359, 354);
            this.lbl_admin_update_course_id.Name = "lbl_admin_update_course_id";
            this.lbl_admin_update_course_id.Size = new System.Drawing.Size(109, 25);
            this.lbl_admin_update_course_id.TabIndex = 112;
            this.lbl_admin_update_course_id.Text = "Course ID";
            // 
            // bnt_admin_update_basic_go
            // 
            this.bnt_admin_update_basic_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_admin_update_basic_go.Location = new System.Drawing.Point(126, 366);
            this.bnt_admin_update_basic_go.Name = "bnt_admin_update_basic_go";
            this.bnt_admin_update_basic_go.Size = new System.Drawing.Size(50, 28);
            this.bnt_admin_update_basic_go.TabIndex = 111;
            this.bnt_admin_update_basic_go.Text = "GO";
            this.bnt_admin_update_basic_go.UseVisualStyleBackColor = true;
            this.bnt_admin_update_basic_go.Click += new System.EventHandler(this.bnt_admin_update_basic_go_Click);
            // 
            // lbl_admin_update_select_intake
            // 
            this.lbl_admin_update_select_intake.AutoSize = true;
            this.lbl_admin_update_select_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_select_intake.Location = new System.Drawing.Point(38, 288);
            this.lbl_admin_update_select_intake.Name = "lbl_admin_update_select_intake";
            this.lbl_admin_update_select_intake.Size = new System.Drawing.Size(138, 25);
            this.lbl_admin_update_select_intake.TabIndex = 110;
            this.lbl_admin_update_select_intake.Text = "Select Intake";
            // 
            // comboBox_admin_update_basic_intake_select
            // 
            this.comboBox_admin_update_basic_intake_select.FormattingEnabled = true;
            this.comboBox_admin_update_basic_intake_select.Location = new System.Drawing.Point(40, 319);
            this.comboBox_admin_update_basic_intake_select.Name = "comboBox_admin_update_basic_intake_select";
            this.comboBox_admin_update_basic_intake_select.Size = new System.Drawing.Size(136, 24);
            this.comboBox_admin_update_basic_intake_select.TabIndex = 109;
            // 
            // txt_admin_update_basic_intake
            // 
            this.txt_admin_update_basic_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_basic_intake.Location = new System.Drawing.Point(362, 316);
            this.txt_admin_update_basic_intake.Name = "txt_admin_update_basic_intake";
            this.txt_admin_update_basic_intake.Size = new System.Drawing.Size(333, 30);
            this.txt_admin_update_basic_intake.TabIndex = 108;
            // 
            // lbl_admin_update_intake
            // 
            this.lbl_admin_update_intake.AutoSize = true;
            this.lbl_admin_update_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_intake.Location = new System.Drawing.Point(359, 288);
            this.lbl_admin_update_intake.Name = "lbl_admin_update_intake";
            this.lbl_admin_update_intake.Size = new System.Drawing.Size(71, 25);
            this.lbl_admin_update_intake.TabIndex = 107;
            this.lbl_admin_update_intake.Text = "Intake";
            // 
            // lbl_top_admin_update_basic
            // 
            this.lbl_top_admin_update_basic.AutoSize = true;
            this.lbl_top_admin_update_basic.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_admin_update_basic.Location = new System.Drawing.Point(379, 9);
            this.lbl_top_admin_update_basic.Name = "lbl_top_admin_update_basic";
            this.lbl_top_admin_update_basic.Size = new System.Drawing.Size(234, 29);
            this.lbl_top_admin_update_basic.TabIndex = 114;
            this.lbl_top_admin_update_basic.Text = "Course Information";
            // 
            // txt_admin_update_basic_course_name
            // 
            this.txt_admin_update_basic_course_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_admin_update_basic_course_name.Location = new System.Drawing.Point(362, 454);
            this.txt_admin_update_basic_course_name.Name = "txt_admin_update_basic_course_name";
            this.txt_admin_update_basic_course_name.Size = new System.Drawing.Size(333, 30);
            this.txt_admin_update_basic_course_name.TabIndex = 116;
            // 
            // lbl_admin_update_course_name
            // 
            this.lbl_admin_update_course_name.AutoSize = true;
            this.lbl_admin_update_course_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin_update_course_name.Location = new System.Drawing.Point(359, 426);
            this.lbl_admin_update_course_name.Name = "lbl_admin_update_course_name";
            this.lbl_admin_update_course_name.Size = new System.Drawing.Size(144, 25);
            this.lbl_admin_update_course_name.TabIndex = 115;
            this.lbl_admin_update_course_name.Text = "Course Name";
            // 
            // btn_admin_update_basic_updateGo
            // 
            this.btn_admin_update_basic_updateGo.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_admin_update_basic_updateGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_basic_updateGo.Location = new System.Drawing.Point(715, 441);
            this.btn_admin_update_basic_updateGo.Name = "btn_admin_update_basic_updateGo";
            this.btn_admin_update_basic_updateGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_basic_updateGo.TabIndex = 117;
            this.btn_admin_update_basic_updateGo.Text = "UPDATE";
            this.btn_admin_update_basic_updateGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_basic_updateGo.Click += new System.EventHandler(this.btn_admin_update_basic_updateGo_Click);
            // 
            // btn_admin_update_basic_deleteGo
            // 
            this.btn_admin_update_basic_deleteGo.BackColor = System.Drawing.Color.Red;
            this.btn_admin_update_basic_deleteGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_admin_update_basic_deleteGo.Location = new System.Drawing.Point(715, 391);
            this.btn_admin_update_basic_deleteGo.Name = "btn_admin_update_basic_deleteGo";
            this.btn_admin_update_basic_deleteGo.Size = new System.Drawing.Size(128, 42);
            this.btn_admin_update_basic_deleteGo.TabIndex = 118;
            this.btn_admin_update_basic_deleteGo.Text = "DELETE";
            this.btn_admin_update_basic_deleteGo.UseVisualStyleBackColor = false;
            this.btn_admin_update_basic_deleteGo.Click += new System.EventHandler(this.btn_admin_update_basic_deleteGo_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(32, 453);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 119;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // btn_back_fm12_show
            // 
            this.btn_back_fm12_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm12_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm12_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm12_show.Location = new System.Drawing.Point(910, 453);
            this.btn_back_fm12_show.Name = "btn_back_fm12_show";
            this.btn_back_fm12_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm12_show.TabIndex = 120;
            this.btn_back_fm12_show.Text = "BACK";
            this.btn_back_fm12_show.UseVisualStyleBackColor = false;
            this.btn_back_fm12_show.Click += new System.EventHandler(this.btn_back_fm12_show_Click);
            // 
            // Form_admin_update_basic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.btn_back_fm12_show);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.btn_admin_update_basic_deleteGo);
            this.Controls.Add(this.btn_admin_update_basic_updateGo);
            this.Controls.Add(this.txt_admin_update_basic_course_name);
            this.Controls.Add(this.lbl_admin_update_course_name);
            this.Controls.Add(this.lbl_top_admin_update_basic);
            this.Controls.Add(this.txt_admin_update_basic_course_id);
            this.Controls.Add(this.lbl_admin_update_course_id);
            this.Controls.Add(this.bnt_admin_update_basic_go);
            this.Controls.Add(this.lbl_admin_update_select_intake);
            this.Controls.Add(this.comboBox_admin_update_basic_intake_select);
            this.Controls.Add(this.txt_admin_update_basic_intake);
            this.Controls.Add(this.lbl_admin_update_intake);
            this.Controls.Add(this.dataGridView_admin_update_basic);
            this.DoubleBuffered = true;
            this.Name = "Form_admin_update_basic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_admin_update_basic_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_admin_update_basic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_admin_update_basic;
        private System.Windows.Forms.TextBox txt_admin_update_basic_course_id;
        private System.Windows.Forms.Label lbl_admin_update_course_id;
        private System.Windows.Forms.Button bnt_admin_update_basic_go;
        private System.Windows.Forms.Label lbl_admin_update_select_intake;
        private System.Windows.Forms.ComboBox comboBox_admin_update_basic_intake_select;
        private System.Windows.Forms.TextBox txt_admin_update_basic_intake;
        private System.Windows.Forms.Label lbl_admin_update_intake;
        private System.Windows.Forms.Label lbl_top_admin_update_basic;
        private System.Windows.Forms.TextBox txt_admin_update_basic_course_name;
        private System.Windows.Forms.Label lbl_admin_update_course_name;
        private System.Windows.Forms.Button btn_admin_update_basic_updateGo;
        private System.Windows.Forms.Button btn_admin_update_basic_deleteGo;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Button btn_back_fm12_show;
    }
}