﻿
namespace smart_department
{
    partial class Form_Data_Show
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Data_Show));
            this.btn_log_out = new System.Windows.Forms.Button();
            this.btn_back_fm4 = new System.Windows.Forms.Button();
            this.btn_Slide_Record_show_data = new System.Windows.Forms.Button();
            this.btn_classlink_show_data = new System.Windows.Forms.Button();
            this.btn_RBook_show_data = new System.Windows.Forms.Button();
            this.btn_notice_show_data = new System.Windows.Forms.Button();
            this.btn_routine_show_data = new System.Windows.Forms.Button();
            this.btn_basic_show_data = new System.Windows.Forms.Button();
            this.lbl_top_show = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(39, 445);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 29;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // btn_back_fm4
            // 
            this.btn_back_fm4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm4.Location = new System.Drawing.Point(900, 442);
            this.btn_back_fm4.Name = "btn_back_fm4";
            this.btn_back_fm4.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm4.TabIndex = 28;
            this.btn_back_fm4.Text = "BACK";
            this.btn_back_fm4.UseVisualStyleBackColor = false;
            this.btn_back_fm4.Click += new System.EventHandler(this.btn_back_fm4_Click);
            // 
            // btn_Slide_Record_show_data
            // 
            this.btn_Slide_Record_show_data.BackColor = System.Drawing.Color.Cyan;
            this.btn_Slide_Record_show_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Slide_Record_show_data.Location = new System.Drawing.Point(419, 286);
            this.btn_Slide_Record_show_data.Name = "btn_Slide_Record_show_data";
            this.btn_Slide_Record_show_data.Size = new System.Drawing.Size(170, 92);
            this.btn_Slide_Record_show_data.TabIndex = 27;
            this.btn_Slide_Record_show_data.Text = "Slide+Record";
            this.btn_Slide_Record_show_data.UseVisualStyleBackColor = false;
            this.btn_Slide_Record_show_data.Click += new System.EventHandler(this.btn_Slide_Record_show_data_Click);
            // 
            // btn_classlink_show_data
            // 
            this.btn_classlink_show_data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_classlink_show_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_classlink_show_data.Location = new System.Drawing.Point(419, 145);
            this.btn_classlink_show_data.Name = "btn_classlink_show_data";
            this.btn_classlink_show_data.Size = new System.Drawing.Size(170, 92);
            this.btn_classlink_show_data.TabIndex = 26;
            this.btn_classlink_show_data.Text = "Class Link";
            this.btn_classlink_show_data.UseVisualStyleBackColor = false;
            this.btn_classlink_show_data.Click += new System.EventHandler(this.btn_classlink_show_data_Click);
            // 
            // btn_RBook_show_data
            // 
            this.btn_RBook_show_data.BackColor = System.Drawing.Color.Fuchsia;
            this.btn_RBook_show_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RBook_show_data.Location = new System.Drawing.Point(195, 286);
            this.btn_RBook_show_data.Name = "btn_RBook_show_data";
            this.btn_RBook_show_data.Size = new System.Drawing.Size(170, 92);
            this.btn_RBook_show_data.TabIndex = 25;
            this.btn_RBook_show_data.Text = "R. Book";
            this.btn_RBook_show_data.UseVisualStyleBackColor = false;
            this.btn_RBook_show_data.Click += new System.EventHandler(this.btn_RBook_show_data_Click);
            // 
            // btn_notice_show_data
            // 
            this.btn_notice_show_data.BackColor = System.Drawing.Color.Orange;
            this.btn_notice_show_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_notice_show_data.Location = new System.Drawing.Point(645, 145);
            this.btn_notice_show_data.Name = "btn_notice_show_data";
            this.btn_notice_show_data.Size = new System.Drawing.Size(170, 92);
            this.btn_notice_show_data.TabIndex = 24;
            this.btn_notice_show_data.Text = "Notice";
            this.btn_notice_show_data.UseVisualStyleBackColor = false;
            this.btn_notice_show_data.Click += new System.EventHandler(this.btn_notice_show_data_Click);
            // 
            // btn_routine_show_data
            // 
            this.btn_routine_show_data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_routine_show_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_routine_show_data.Location = new System.Drawing.Point(645, 286);
            this.btn_routine_show_data.Name = "btn_routine_show_data";
            this.btn_routine_show_data.Size = new System.Drawing.Size(170, 92);
            this.btn_routine_show_data.TabIndex = 22;
            this.btn_routine_show_data.Text = "Routine";
            this.btn_routine_show_data.UseVisualStyleBackColor = false;
            this.btn_routine_show_data.Click += new System.EventHandler(this.btn_routine_show_data_Click);
            // 
            // btn_basic_show_data
            // 
            this.btn_basic_show_data.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_basic_show_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_basic_show_data.Location = new System.Drawing.Point(195, 145);
            this.btn_basic_show_data.Name = "btn_basic_show_data";
            this.btn_basic_show_data.Size = new System.Drawing.Size(170, 92);
            this.btn_basic_show_data.TabIndex = 21;
            this.btn_basic_show_data.Text = "Basic";
            this.btn_basic_show_data.UseVisualStyleBackColor = false;
            this.btn_basic_show_data.Click += new System.EventHandler(this.btn_basic_show_data_Click);
            // 
            // lbl_top_show
            // 
            this.lbl_top_show.AutoSize = true;
            this.lbl_top_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_show.Location = new System.Drawing.Point(445, 9);
            this.lbl_top_show.Name = "lbl_top_show";
            this.lbl_top_show.Size = new System.Drawing.Size(138, 29);
            this.lbl_top_show.TabIndex = 94;
            this.lbl_top_show.Text = "Show Data";
            // 
            // Form_Data_Show
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.lbl_top_show);
            this.Controls.Add(this.btn_log_out);
            this.Controls.Add(this.btn_back_fm4);
            this.Controls.Add(this.btn_Slide_Record_show_data);
            this.Controls.Add(this.btn_classlink_show_data);
            this.Controls.Add(this.btn_RBook_show_data);
            this.Controls.Add(this.btn_notice_show_data);
            this.Controls.Add(this.btn_routine_show_data);
            this.Controls.Add(this.btn_basic_show_data);
            this.DoubleBuffered = true;
            this.Name = "Form_Data_Show";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_Data_Show_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.Button btn_back_fm4;
        private System.Windows.Forms.Button btn_Slide_Record_show_data;
        private System.Windows.Forms.Button btn_classlink_show_data;
        private System.Windows.Forms.Button btn_RBook_show_data;
        private System.Windows.Forms.Button btn_notice_show_data;
        private System.Windows.Forms.Button btn_routine_show_data;
        private System.Windows.Forms.Button btn_basic_show_data;
        private System.Windows.Forms.Label lbl_top_show;
    }
}