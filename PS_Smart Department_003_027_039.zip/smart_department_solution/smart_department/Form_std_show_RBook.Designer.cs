﻿
namespace smart_department
{
    partial class Form_std_show_RBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_std_show_RBook));
            this.lbl_top_std_show_RBook = new System.Windows.Forms.Label();
            this.txt_std_show_RBook_sec = new System.Windows.Forms.TextBox();
            this.lbl_std_show_RBook_sec = new System.Windows.Forms.Label();
            this.bnt_std_show_RBook_go = new System.Windows.Forms.Button();
            this.lbl_std_show_RBook_intake_select = new System.Windows.Forms.Label();
            this.comboBox_std_show_RBook_intake = new System.Windows.Forms.ComboBox();
            this.txt_std_show_RBook_intake = new System.Windows.Forms.TextBox();
            this.lbl_std_show_RBook_intake = new System.Windows.Forms.Label();
            this.dataGridView_std_show_RBook = new System.Windows.Forms.DataGridView();
            this.btn_back_fm24_show = new System.Windows.Forms.Button();
            this.btn_log_out = new System.Windows.Forms.Button();
            this.txt_std_show_RBook_selectlink = new System.Windows.Forms.TextBox();
            this.linkLbl_golink = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_std_show_RBook)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_top_std_show_RBook
            // 
            this.lbl_top_std_show_RBook.AutoSize = true;
            this.lbl_top_std_show_RBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_top_std_show_RBook.Location = new System.Drawing.Point(411, 9);
            this.lbl_top_std_show_RBook.Name = "lbl_top_std_show_RBook";
            this.lbl_top_std_show_RBook.Size = new System.Drawing.Size(201, 29);
            this.lbl_top_std_show_RBook.TabIndex = 106;
            this.lbl_top_std_show_RBook.Text = "Reference Book";
            // 
            // txt_std_show_RBook_sec
            // 
            this.txt_std_show_RBook_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_std_show_RBook_sec.Location = new System.Drawing.Point(40, 303);
            this.txt_std_show_RBook_sec.Name = "txt_std_show_RBook_sec";
            this.txt_std_show_RBook_sec.Size = new System.Drawing.Size(174, 30);
            this.txt_std_show_RBook_sec.TabIndex = 105;
            // 
            // lbl_std_show_RBook_sec
            // 
            this.lbl_std_show_RBook_sec.AutoSize = true;
            this.lbl_std_show_RBook_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_std_show_RBook_sec.Location = new System.Drawing.Point(37, 275);
            this.lbl_std_show_RBook_sec.Name = "lbl_std_show_RBook_sec";
            this.lbl_std_show_RBook_sec.Size = new System.Drawing.Size(85, 25);
            this.lbl_std_show_RBook_sec.TabIndex = 104;
            this.lbl_std_show_RBook_sec.Text = "Section";
            // 
            // bnt_std_show_RBook_go
            // 
            this.bnt_std_show_RBook_go.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_std_show_RBook_go.Location = new System.Drawing.Point(158, 339);
            this.bnt_std_show_RBook_go.Name = "bnt_std_show_RBook_go";
            this.bnt_std_show_RBook_go.Size = new System.Drawing.Size(56, 28);
            this.bnt_std_show_RBook_go.TabIndex = 103;
            this.bnt_std_show_RBook_go.Text = "GO";
            this.bnt_std_show_RBook_go.UseVisualStyleBackColor = true;
            this.bnt_std_show_RBook_go.Click += new System.EventHandler(this.bnt_std_show_RBook_go_Click);
            // 
            // lbl_std_show_RBook_intake_select
            // 
            this.lbl_std_show_RBook_intake_select.AutoSize = true;
            this.lbl_std_show_RBook_intake_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_std_show_RBook_intake_select.Location = new System.Drawing.Point(37, 144);
            this.lbl_std_show_RBook_intake_select.Name = "lbl_std_show_RBook_intake_select";
            this.lbl_std_show_RBook_intake_select.Size = new System.Drawing.Size(138, 25);
            this.lbl_std_show_RBook_intake_select.TabIndex = 102;
            this.lbl_std_show_RBook_intake_select.Text = "Select Intake";
            // 
            // comboBox_std_show_RBook_intake
            // 
            this.comboBox_std_show_RBook_intake.FormattingEnabled = true;
            this.comboBox_std_show_RBook_intake.Location = new System.Drawing.Point(39, 175);
            this.comboBox_std_show_RBook_intake.Name = "comboBox_std_show_RBook_intake";
            this.comboBox_std_show_RBook_intake.Size = new System.Drawing.Size(174, 24);
            this.comboBox_std_show_RBook_intake.TabIndex = 101;
            this.comboBox_std_show_RBook_intake.SelectedIndexChanged += new System.EventHandler(this.comboBox_std_show_RBook_intake_SelectedIndexChanged);
            // 
            // txt_std_show_RBook_intake
            // 
            this.txt_std_show_RBook_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_std_show_RBook_intake.Location = new System.Drawing.Point(40, 237);
            this.txt_std_show_RBook_intake.Name = "txt_std_show_RBook_intake";
            this.txt_std_show_RBook_intake.Size = new System.Drawing.Size(174, 30);
            this.txt_std_show_RBook_intake.TabIndex = 100;
            // 
            // lbl_std_show_RBook_intake
            // 
            this.lbl_std_show_RBook_intake.AutoSize = true;
            this.lbl_std_show_RBook_intake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_std_show_RBook_intake.Location = new System.Drawing.Point(37, 209);
            this.lbl_std_show_RBook_intake.Name = "lbl_std_show_RBook_intake";
            this.lbl_std_show_RBook_intake.Size = new System.Drawing.Size(71, 25);
            this.lbl_std_show_RBook_intake.TabIndex = 99;
            this.lbl_std_show_RBook_intake.Text = "Intake";
            // 
            // dataGridView_std_show_RBook
            // 
            this.dataGridView_std_show_RBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_std_show_RBook.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.dataGridView_std_show_RBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_std_show_RBook.Location = new System.Drawing.Point(231, 63);
            this.dataGridView_std_show_RBook.Name = "dataGridView_std_show_RBook";
            this.dataGridView_std_show_RBook.RowHeadersVisible = false;
            this.dataGridView_std_show_RBook.RowHeadersWidth = 51;
            this.dataGridView_std_show_RBook.RowTemplate.Height = 24;
            this.dataGridView_std_show_RBook.Size = new System.Drawing.Size(743, 374);
            this.dataGridView_std_show_RBook.TabIndex = 98;
            this.dataGridView_std_show_RBook.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_std_show_RBook_CellContentClick);
            // 
            // btn_back_fm24_show
            // 
            this.btn_back_fm24_show.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_back_fm24_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back_fm24_show.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back_fm24_show.Location = new System.Drawing.Point(901, 444);
            this.btn_back_fm24_show.Name = "btn_back_fm24_show";
            this.btn_back_fm24_show.Size = new System.Drawing.Size(76, 33);
            this.btn_back_fm24_show.TabIndex = 97;
            this.btn_back_fm24_show.Text = "BACK";
            this.btn_back_fm24_show.UseVisualStyleBackColor = false;
            this.btn_back_fm24_show.Click += new System.EventHandler(this.btn_back_fm24_show_Click);
            // 
            // btn_log_out
            // 
            this.btn_log_out.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_log_out.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_log_out.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_log_out.Location = new System.Drawing.Point(40, 447);
            this.btn_log_out.Name = "btn_log_out";
            this.btn_log_out.Size = new System.Drawing.Size(134, 30);
            this.btn_log_out.TabIndex = 96;
            this.btn_log_out.Text = "LOG OUT";
            this.btn_log_out.UseVisualStyleBackColor = false;
            this.btn_log_out.Click += new System.EventHandler(this.btn_log_out_Click);
            // 
            // txt_std_show_RBook_selectlink
            // 
            this.txt_std_show_RBook_selectlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_std_show_RBook_selectlink.Location = new System.Drawing.Point(231, 450);
            this.txt_std_show_RBook_selectlink.Name = "txt_std_show_RBook_selectlink";
            this.txt_std_show_RBook_selectlink.Size = new System.Drawing.Size(574, 22);
            this.txt_std_show_RBook_selectlink.TabIndex = 112;
            // 
            // linkLbl_golink
            // 
            this.linkLbl_golink.AutoSize = true;
            this.linkLbl_golink.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLbl_golink.Location = new System.Drawing.Point(811, 451);
            this.linkLbl_golink.Name = "linkLbl_golink";
            this.linkLbl_golink.Size = new System.Drawing.Size(84, 20);
            this.linkLbl_golink.TabIndex = 111;
            this.linkLbl_golink.TabStop = true;
            this.linkLbl_golink.Text = "GO LINK";
            this.linkLbl_golink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLbl_golink_LinkClicked);
            // 
            // Form_std_show_RBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1015, 540);
            this.Controls.Add(this.txt_std_show_RBook_selectlink);
            this.Controls.Add(this.linkLbl_golink);
            this.Controls.Add(this.lbl_top_std_show_RBook);
            this.Controls.Add(this.txt_std_show_RBook_sec);
            this.Controls.Add(this.lbl_std_show_RBook_sec);
            this.Controls.Add(this.bnt_std_show_RBook_go);
            this.Controls.Add(this.lbl_std_show_RBook_intake_select);
            this.Controls.Add(this.comboBox_std_show_RBook_intake);
            this.Controls.Add(this.txt_std_show_RBook_intake);
            this.Controls.Add(this.lbl_std_show_RBook_intake);
            this.Controls.Add(this.dataGridView_std_show_RBook);
            this.Controls.Add(this.btn_back_fm24_show);
            this.Controls.Add(this.btn_log_out);
            this.DoubleBuffered = true;
            this.Name = "Form_std_show_RBook";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Department";
            this.Load += new System.EventHandler(this.Form_std_show_RBook_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_std_show_RBook)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_top_std_show_RBook;
        private System.Windows.Forms.TextBox txt_std_show_RBook_sec;
        private System.Windows.Forms.Label lbl_std_show_RBook_sec;
        private System.Windows.Forms.Button bnt_std_show_RBook_go;
        private System.Windows.Forms.Label lbl_std_show_RBook_intake_select;
        private System.Windows.Forms.ComboBox comboBox_std_show_RBook_intake;
        private System.Windows.Forms.TextBox txt_std_show_RBook_intake;
        private System.Windows.Forms.Label lbl_std_show_RBook_intake;
        private System.Windows.Forms.DataGridView dataGridView_std_show_RBook;
        private System.Windows.Forms.Button btn_back_fm24_show;
        private System.Windows.Forms.Button btn_log_out;
        private System.Windows.Forms.TextBox txt_std_show_RBook_selectlink;
        private System.Windows.Forms.LinkLabel linkLbl_golink;
    }
}